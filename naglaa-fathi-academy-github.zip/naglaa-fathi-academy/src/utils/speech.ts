export interface SpeakOptions {
  lang?: 'ar-EG' | 'en-US';
  rate?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: () => void;
}

class SpeechController {
  private supported =
    typeof window !== 'undefined' && 'speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined';

  isSupported(): boolean {
    return this.supported;
  }

  stop(): void {
    if (!this.supported) return;
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }

  private pickVoice(langPrefix: string): SpeechSynthesisVoice | null {
    if (!this.supported) return null;
    const voices = window.speechSynthesis.getVoices();
    if (!voices || voices.length === 0) return null;

    // Prefer exact Egyptian Arabic or general Arabic voice; prefer female voice if named
    const matching = voices.filter((v) => v.lang.toLowerCase().startsWith(langPrefix.toLowerCase()));
    if (matching.length > 0) {
      const preferred = matching.find((v) =>
        /naglaa|salma|hoda|laila|fatima|mariam|female|eg/i.test(v.name + ' ' + v.lang)
      );
      return preferred || matching[0];
    }

    if (langPrefix.startsWith('ar')) {
      const anyAr = voices.find((v) => v.lang.toLowerCase().includes('ar'));
      if (anyAr) return anyAr;
    }

    return null;
  }

  speak(text: string, options: SpeakOptions = {}): boolean {
    const cleanText = String(text || '').trim();
    if (!cleanText) return false;

    if (!this.supported) {
      options.onError?.();
      return false;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanText);
      const targetLang = options.lang || 'ar-EG';
      utterance.lang = targetLang;
      utterance.rate = options.rate ?? 0.95;
      utterance.pitch = 1.04;

      const voice = this.pickVoice(targetLang.slice(0, 2));
      if (voice) {
        utterance.voice = voice;
      }

      utterance.onstart = () => options.onStart?.();
      utterance.onend = () => options.onEnd?.();
      utterance.onerror = () => options.onError?.();

      window.speechSynthesis.speak(utterance);
      return true;
    } catch {
      options.onError?.();
      return false;
    }
  }
}

export const speechController = new SpeechController();
