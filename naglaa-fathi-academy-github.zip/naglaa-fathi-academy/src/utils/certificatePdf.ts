import type { Certificate } from '../types.ts';
import { BRANCH_LABELS, GRADE_LABELS } from './academy.ts';

const CERT_WIDTH = 1754;
const CERT_HEIGHT = 1240;

function formatArabicDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return iso.slice(0, 10);
  }
}

export function renderCertificateToCanvas(
  canvas: HTMLCanvasElement,
  cert: Certificate
): void {
  canvas.width = CERT_WIDTH;
  canvas.height = CERT_HEIGHT;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const W = CERT_WIDTH;
  const H = CERT_HEIGHT;

  // 1. Warm Ivory Parchment Background
  const bgGrad = ctx.createRadialGradient(W / 2, H / 2, 120, W / 2, H / 2, W * 0.68);
  bgGrad.addColorStop(0, '#fffdf7');
  bgGrad.addColorStop(1, '#f8f2e4');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  // Subtle decorative corner watermark geometry (academic medallion rings)
  ctx.save();
  ctx.strokeStyle = 'rgba(180, 132, 42, 0.08)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(W / 2, H / 2, 340, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(W / 2, H / 2, 390, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  // 2. Royal Navy & Gold Double Ornamental Frame
  ctx.strokeStyle = '#1e3a8a';
  ctx.lineWidth = 14;
  ctx.strokeRect(42, 42, W - 84, H - 84);

  ctx.strokeStyle = '#c5922b';
  ctx.lineWidth = 5;
  ctx.strokeRect(64, 64, W - 128, H - 128);

  ctx.strokeStyle = '#1e3a8a';
  ctx.lineWidth = 2;
  ctx.strokeRect(78, 78, W - 156, H - 156);

  // Ornamental Gold Corner Accents
  const corners = [
    [64, 64, 1, 1],
    [W - 64, 64, -1, 1],
    [64, H - 64, 1, -1],
    [W - 64, H - 64, -1, -1],
  ];
  corners.forEach(([cx, cy, dx, dy]) => {
    ctx.fillStyle = '#c5922b';
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + dx * 68, cy);
    ctx.lineTo(cx, cy + dy * 68);
    ctx.closePath();
    ctx.fill();
  });

  // 3. Top Header Banner & Platform Title
  ctx.direction = 'rtl';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  ctx.fillStyle = '#1e3a8a';
  ctx.font = 'bold 34px Cairo, "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText(cert.platformName, W / 2, 148);

  // Decorative Gold Line Under Platform Name
  ctx.strokeStyle = '#c5922b';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(W / 2 - 260, 186);
  ctx.lineTo(W / 2 + 260, 186);
  ctx.stroke();

  // 4. Main Certificate Heading
  ctx.fillStyle = '#0f172a';
  ctx.font = '800 72px Cairo, "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText('شهادة إتمام وتفوق', W / 2, 274);

  ctx.fillStyle = '#b45309';
  ctx.font = 'bold 28px Cairo, "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText(
    `إنجاز خطة الشهر الكاملة (${cert.completedLessonsCount} من ${cert.totalLessonsCount} محاضرات)`,
    W / 2,
    344
  );

  // 5. Recipient Statement
  ctx.fillStyle = '#334155';
  ctx.font = '600 32px "IBM Plex Sans Arabic", Cairo, sans-serif';
  ctx.fillText('تشهد إدارة المنصة بأن الطالب / الطالبة:', W / 2, 434);

  // Highlighted Student Name Box
  ctx.fillStyle = '#eff6ff';
  ctx.strokeStyle = '#93c5fd';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.roundRect(W / 2 - 430, 480, 860, 118, 20);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = '#1e3a8a';
  ctx.font = '800 54px Cairo, "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText(cert.studentName, W / 2, 540);

  // 6. Course & Completion Details
  ctx.fillStyle = '#1e293b';
  ctx.font = '600 30px "IBM Plex Sans Arabic", Cairo, sans-serif';
  ctx.fillText('قد أتم بنجاح وحضور منتظم جميع المحاضرات الكرتونية والشرح المقرر في:', W / 2, 658);

  ctx.fillStyle = '#047857';
  ctx.font = '800 40px Cairo, "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText(cert.courseTitle, W / 2, 728);

  ctx.fillStyle = '#475569';
  ctx.font = '600 26px "IBM Plex Sans Arabic", Cairo, sans-serif';
  ctx.fillText(
    `${GRADE_LABELS[cert.grade]}  ·  ${BRANCH_LABELS[cert.branch]}  ·  ${cert.monthLabel}`,
    W / 2,
    788
  );

  // 7. Bottom Section: Signature, Official Gold Seal, and Serial Verification
  const bottomY = 980;

  // Gold Medallion Seal in Center
  const sealX = W / 2;
  const sealY = bottomY - 10;

  // Ribbon tails
  ctx.fillStyle = '#1e3a8a';
  ctx.beginPath();
  ctx.moveTo(sealX - 38, sealY + 45);
  ctx.lineTo(sealX - 62, sealY + 135);
  ctx.lineTo(sealX - 24, sealY + 110);
  ctx.lineTo(sealX - 6, sealY + 135);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(sealX + 38, sealY + 45);
  ctx.lineTo(sealX + 62, sealY + 135);
  ctx.lineTo(sealX + 24, sealY + 110);
  ctx.lineTo(sealX + 6, sealY + 135);
  ctx.closePath();
  ctx.fill();

  // Outer serrated seal look
  const sealGrad = ctx.createLinearGradient(sealX - 75, sealY - 75, sealX + 75, sealY + 75);
  sealGrad.addColorStop(0, '#fbbf24');
  sealGrad.addColorStop(0.5, '#d97706');
  sealGrad.addColorStop(1, '#f59e0b');

  ctx.fillStyle = sealGrad;
  ctx.beginPath();
  for (let i = 0; i < 24; i++) {
    const angle = (i / 24) * Math.PI * 2;
    const radius = i % 2 === 0 ? 78 : 68;
    const px = sealX + Math.cos(angle) * radius;
    const py = sealY + Math.sin(angle) * radius;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#fffbeb';
  ctx.beginPath();
  ctx.arc(sealX, sealY, 54, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#b45309';
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = '#92400e';
  ctx.font = '800 22px Cairo, sans-serif';
  ctx.fillText('إنجاز 100%', sealX, sealY - 10);
  ctx.font = 'bold 17px Cairo, sans-serif';
  ctx.fillText('8 محاضرات', sealX, sealY + 20);

  // Right Side (RTL): Teacher Signature
  const sigX = W - 320;
  ctx.fillStyle = '#475569';
  ctx.font = '600 23px "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText('إشراف واعتماد معلمة المادة', sigX, bottomY - 35);

  ctx.fillStyle = '#1e3a8a';
  ctx.font = '800 32px Cairo, "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText(cert.teacherName, sigX, bottomY + 14);

  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(sigX - 150, bottomY + 46);
  ctx.lineTo(sigX + 150, bottomY + 46);
  ctx.stroke();

  // Left Side (RTL): Issue Date & Verification Serial Number
  const metaX = 320;
  ctx.fillStyle = '#475569';
  ctx.font = '600 22px "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText(`تاريخ الإصدار: ${formatArabicDate(cert.issuedAt)}`, metaX, bottomY - 35);

  ctx.direction = 'ltr';
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 22px "JetBrains Mono", monospace';
  ctx.fillText(`CERT ID: ${cert.certificateNumber}`, metaX, bottomY + 14);

  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(metaX - 165, bottomY + 46);
  ctx.lineTo(metaX + 165, bottomY + 46);
  ctx.stroke();

  // Footer note
  ctx.direction = 'rtl';
  ctx.fillStyle = '#64748b';
  ctx.font = '500 20px "IBM Plex Sans Arabic", sans-serif';
  ctx.fillText(
    'شهادة صادرة آلياً من نظام متابعة الطلاب بالمنصة عند إتمام كافة المحاضرات الشهرية',
    W / 2,
    H - 110
  );
}

function base64ToUint8Array(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Wraps a crisp JPEG image inside a valid A4 Landscape PDF 1.4 binary document.
 */
export function buildPdfBytesFromJpeg(
  jpegBytes: Uint8Array,
  imageWidth: number,
  imageHeight: number
): Uint8Array {
  const enc = new TextEncoder();
  const chunks: Uint8Array[] = [];
  const offsets: number[] = [0];
  let bytePos = 0;

  const pushBytes = (bytes: Uint8Array) => {
    chunks.push(bytes);
    bytePos += bytes.length;
  };
  const pushAscii = (text: string) => pushBytes(enc.encode(text));

  // Header + binary marker
  pushAscii('%PDF-1.4\n');
  pushBytes(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));

  // Obj 1: Catalog
  offsets[1] = bytePos;
  pushAscii('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');

  // Obj 2: Pages
  offsets[2] = bytePos;
  pushAscii('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n');

  // Obj 3: Page (A4 Landscape: 841.89 x 595.28 pt)
  offsets[3] = bytePos;
  pushAscii(
    '3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 841.89 595.28] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>\nendobj\n'
  );

  // Obj 4: JPEG Image XObject
  offsets[4] = bytePos;
  pushAscii(
    `4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${imageWidth} /Height ${imageHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.length} >>\nstream\n`
  );
  pushBytes(jpegBytes);
  pushAscii('\nendstream\nendobj\n');

  // Obj 5: Content stream drawing the JPEG full-bleed across the A4 Landscape page
  const drawCmd = 'q\n841.89 0 0 595.28 0 0 cm\n/Im0 Do\nQ\n';
  offsets[5] = bytePos;
  pushAscii(`5 0 obj\n<< /Length ${drawCmd.length} >>\nstream\n${drawCmd}endstream\nendobj\n`);

  // XRef table
  const xrefPos = bytePos;
  pushAscii('xref\n0 6\n');
  pushAscii('0000000000 65535 f \n');
  for (let i = 1; i <= 5; i++) {
    pushAscii(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
  }

  // Trailer
  pushAscii(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`);

  const merged = new Uint8Array(bytePos);
  let cursor = 0;
  for (const chunk of chunks) {
    merged.set(chunk, cursor);
    cursor += chunk.length;
  }
  return merged;
}

export async function downloadCertificateAsPdf(cert: Certificate): Promise<void> {
  if (typeof document !== 'undefined' && 'fonts' in document) {
    try {
      await document.fonts.ready;
    } catch {
      // proceed with fallback system fonts
    }
  }

  const canvas = document.createElement('canvas');
  renderCertificateToCanvas(canvas, cert);

  const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
  const base64 = dataUrl.split(',')[1] || '';
  const jpegBytes = base64ToUint8Array(base64);
  const pdfBytes = buildPdfBytesFromJpeg(jpegBytes, CERT_WIDTH, CERT_HEIGHT);

  const pdfBuffer = new Uint8Array(pdfBytes).buffer;
  const blob = new Blob([pdfBuffer], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  const safeCode = cert.certificateNumber.replace(/[^a-zA-Z0-9-_]/g, '');
  anchor.download = `شهادة-إتمام-${safeCode}.pdf`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
