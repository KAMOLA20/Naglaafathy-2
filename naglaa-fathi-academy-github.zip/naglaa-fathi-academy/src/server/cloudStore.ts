import fs from 'fs';
import path from 'path';
import { Pool } from 'pg';

export type CloudStorageMode = 'postgres' | 'upstash-redis' | 'local-file';

export interface CloudStoreOptions<T> {
  dataDir: string;
  localFilePath: string;
  createInitial: () => T;
  normalize: (raw: unknown) => T | null;
}

export interface CloudStoreAdapter<T> {
  readonly mode: CloudStorageMode;
  load: () => Promise<T>;
  save: (data: T, opts?: { immediate?: boolean }) => void;
  flush: () => Promise<void>;
}

const POSTGRES_KEY = 'main';
const UPSTASH_KEY = 'kamola:cairo:store:v1';

function shouldUseSsl(connectionString: string): boolean {
  const lower = connectionString.toLowerCase();
  if (lower.includes('sslmode=disable')) return false;
  if (lower.includes('localhost') || lower.includes('127.0.0.1')) return false;
  return true;
}

export function createCloudStore<T>(options: CloudStoreOptions<T>): CloudStoreAdapter<T> {
  const databaseUrl = (process.env.DATABASE_URL || '').trim();
  const upstashUrl = (process.env.UPSTASH_REDIS_REST_URL || '').trim().replace(/\/$/, '');
  const upstashToken = (process.env.UPSTASH_REDIS_REST_TOKEN || '').trim();

  const mode: CloudStorageMode = databaseUrl
    ? 'postgres'
    : upstashUrl && upstashToken
      ? 'upstash-redis'
      : 'local-file';

  let pgPool: Pool | null = null;
  if (mode === 'postgres') {
    pgPool = new Pool({
      connectionString: databaseUrl,
      ssl: shouldUseSsl(databaseUrl) ? { rejectUnauthorized: false } : false,
      max: 5,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 15_000,
    });
    pgPool.on('error', (err) => {
      console.error('[cloudStore] PostgreSQL pool error:', err);
    });
  }

  let debounceTimer: NodeJS.Timeout | null = null;
  let pendingData: T | null = null;
  let writeChain: Promise<void> = Promise.resolve();

  function readLocalFile(): T | null {
    try {
      if (!fs.existsSync(options.localFilePath)) return null;
      const raw = fs.readFileSync(options.localFilePath, 'utf-8');
      return options.normalize(JSON.parse(raw));
    } catch (err) {
      console.error('[cloudStore] Failed to read local store file:', err);
      return null;
    }
  }

  function writeLocalFile(data: T): void {
    try {
      if (!fs.existsSync(options.dataDir)) {
        fs.mkdirSync(options.dataDir, { recursive: true });
      }
      fs.writeFileSync(options.localFilePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('[cloudStore] Failed to write local store file:', err);
    }
  }

  async function ensurePostgresTable(): Promise<void> {
    if (!pgPool) return;
    await pgPool.query(`
      CREATE TABLE IF NOT EXISTS kamola_store (
        store_key TEXT PRIMARY KEY,
        payload JSONB NOT NULL,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);
  }

  async function readPostgres(): Promise<T | null> {
    if (!pgPool) return null;
    await ensurePostgresTable();
    const res = await pgPool.query<{ payload: unknown }>(
      'SELECT payload FROM kamola_store WHERE store_key = $1 LIMIT 1',
      [POSTGRES_KEY]
    );
    if (res.rows.length === 0) return null;
    return options.normalize(res.rows[0].payload);
  }

  async function writePostgres(data: T): Promise<void> {
    if (!pgPool) return;
    await pgPool.query(
      `INSERT INTO kamola_store (store_key, payload, updated_at)
       VALUES ($1, $2::jsonb, NOW())
       ON CONFLICT (store_key)
       DO UPDATE SET payload = EXCLUDED.payload, updated_at = NOW()`,
      [POSTGRES_KEY, JSON.stringify(data)]
    );
  }

  async function readUpstash(): Promise<T | null> {
    const res = await fetch(upstashUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${upstashToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(['GET', UPSTASH_KEY]),
    });
    if (!res.ok) {
      throw new Error(`Upstash GET failed with status ${res.status}`);
    }
    const json = (await res.json()) as { result?: string | null };
    if (!json || !json.result) return null;
    const parsed = typeof json.result === 'string' ? JSON.parse(json.result) : json.result;
    return options.normalize(parsed);
  }

  async function writeUpstash(data: T): Promise<void> {
    const res = await fetch(upstashUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${upstashToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(['SET', UPSTASH_KEY, JSON.stringify(data)]),
    });
    if (!res.ok) {
      throw new Error(`Upstash SET failed with status ${res.status}`);
    }
  }

  async function persistNow(data: T): Promise<void> {
    if (mode === 'postgres') {
      await writePostgres(data);
      return;
    }
    if (mode === 'upstash-redis') {
      await writeUpstash(data);
      return;
    }
    writeLocalFile(data);
  }

  function enqueueFlush(): Promise<void> {
    if (!pendingData) return writeChain;
    const snapshotToSave = pendingData;
    pendingData = null;

    writeChain = writeChain
      .then(() => persistNow(snapshotToSave))
      .catch((err) => {
        console.error(`[cloudStore] Failed to persist to ${mode}:`, err);
      });

    return writeChain;
  }

  async function load(): Promise<T> {
    if (mode === 'postgres') {
      try {
        const existing = await readPostgres();
        if (existing) {
          console.log('[cloudStore] Loaded state from PostgreSQL cloud database');
          return existing;
        }
        const seed = readLocalFile() || options.createInitial();
        await writePostgres(seed);
        console.log('[cloudStore] Initialized PostgreSQL cloud database with KAMOLA data');
        return seed;
      } catch (err) {
        console.error('[cloudStore] PostgreSQL load error, falling back to local cache:', err);
      }
    } else if (mode === 'upstash-redis') {
      try {
        const existing = await readUpstash();
        if (existing) {
          console.log('[cloudStore] Loaded state from Upstash Redis cloud database');
          return existing;
        }
        const seed = readLocalFile() || options.createInitial();
        await writeUpstash(seed);
        console.log('[cloudStore] Initialized Upstash Redis cloud database with KAMOLA data');
        return seed;
      } catch (err) {
        console.error('[cloudStore] Upstash Redis load error, falling back to local cache:', err);
      }
    }

    const local = readLocalFile();
    if (local) return local;
    const initial = options.createInitial();
    writeLocalFile(initial);
    return initial;
  }

  function save(data: T, opts?: { immediate?: boolean }): void {
    pendingData = data;
    if (mode === 'local-file') {
      if (debounceTimer) {
        clearTimeout(debounceTimer);
        debounceTimer = null;
      }
      writeLocalFile(data);
      pendingData = null;
      return;
    }

    const immediate = opts?.immediate ?? true;
    if (immediate) {
      if (debounceTimer) {
        clearTimeout(debounceTimer);
        debounceTimer = null;
      }
      void enqueueFlush();
      return;
    }

    if (!debounceTimer) {
      debounceTimer = setTimeout(() => {
        debounceTimer = null;
        void enqueueFlush();
      }, 2000);
    }
  }

  async function flush(): Promise<void> {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    await enqueueFlush();
  }

  return {
    mode,
    load,
    save,
    flush,
  };
}
