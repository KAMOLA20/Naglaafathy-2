import { useEffect, useState } from 'react';
import { RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { speechController } from '../utils/speech.ts';

type LabMode = 'fractions' | 'multiplication' | 'arabic_letters';

const ARABIC_LETTERS: Array<{
  char: string;
  name: string;
  fathaWord: string;
  dammaWord: string;
  kasraWord: string;
  syllables: string;
}> = [
  { char: 'أ', name: 'الألف', fathaWord: 'أَسَد', dammaWord: 'أُذُن', kasraWord: 'إِبْرَة', syllables: 'أَ / سَـ / د' },
  { char: 'ب', name: 'الباء', fathaWord: 'بَطَّة', dammaWord: 'بُرْتُقَال', kasraWord: 'بِنْت', syllables: 'بَطْ / طَـ / ة' },
  { char: 'ت', name: 'التاء', fathaWord: 'تَمْر', dammaWord: 'تُفَّاح', kasraWord: 'تِين', syllables: 'تَـمْـ / ر' },
  { char: 'ج', name: 'الجيم', fathaWord: 'جَمَل', dammaWord: 'جُبْن', kasraWord: 'جِسْر', syllables: 'جَـ / مَـ / ل' },
  { char: 'س', name: 'السين', fathaWord: 'سَمَكَة', dammaWord: 'سُلَحْفَاة', kasraWord: 'سِتَارَة', syllables: 'سَـ / مَـ / كَـ / ة' },
  { char: 'ق', name: 'القاف', fathaWord: 'قَلَم', dammaWord: 'قُبَّعَة', kasraWord: 'قِطَّة', syllables: 'قَـ / لَـ / م' },
  { char: 'ك', name: 'الكاف', fathaWord: 'كَلْب', dammaWord: 'كُرَة', kasraWord: 'كِتَاب', syllables: 'كِـ / تَا / ب' },
  { char: 'م', name: 'الميم', fathaWord: 'مَوْز', dammaWord: 'مُعَلِّم', kasraWord: 'مِفْتَاح', syllables: 'مِفْـ / تَا / ح' },
];

export function PrimaryInteractiveLab() {
  const [mode, setMode] = useState<LabMode>('fractions');

  // Fraction sandbox
  const [numerator, setNumerator] = useState(3);
  const [denominator, setDenominator] = useState(4);

  // Multiplication array sandbox
  const [rows, setRows] = useState(4);
  const [cols, setCols] = useState(6);

  // Arabic letter sandbox
  const [letterIdx, setLetterIdx] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    return () => {
      speechController.stop();
    };
  }, []);

  const safeNumerator = Math.min(numerator, denominator);
  const decimalValue = (safeNumerator / denominator).toFixed(2);
  const percentValue = Math.round((safeNumerator / denominator) * 100);

  // SVG Pizza circle slices
  const radius = 110;
  const cx = 135;
  const cy = 135;

  const slicePaths = Array.from({ length: denominator }, (_, idx) => {
    const startAngle = (idx / denominator) * 2 * Math.PI - Math.PI / 2;
    const endAngle = ((idx + 1) / denominator) * 2 * Math.PI - Math.PI / 2;
    const x1 = cx + radius * Math.cos(startAngle);
    const y1 = cy + radius * Math.sin(startAngle);
    const x2 = cx + radius * Math.cos(endAngle);
    const y2 = cy + radius * Math.sin(endAngle);
    const largeArc = 1 / denominator > 0.5 ? 1 : 0;
    const filled = idx < safeNumerator;
    const d =
      denominator === 1
        ? `M ${cx} ${cy - radius} A ${radius} ${radius} 0 1 1 ${cx - 0.01} ${cy - radius} Z`
        : `M ${cx} ${cy} L ${x1.toFixed(1)} ${y1.toFixed(1)} A ${radius} ${radius} 0 ${largeArc} 1 ${x2.toFixed(1)} ${y2.toFixed(1)} Z`;
    return { d, filled };
  });

  const activeLetter = ARABIC_LETTERS[letterIdx];

  const handleReset = () => {
    setNumerator(3);
    setDenominator(4);
    setRows(4);
    setCols(6);
    setLetterIdx(0);
  };

  return (
    <div className="space-y-6 pb-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">أنشطة بصرية للمرحلة الابتدائية ورياض الأطفال</p>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-display mt-1">
            المختبر التفاعلي للعربي والرياضيات
          </h1>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>إعادة ضبط</span>
        </button>
      </div>

      {/* Mode Switcher */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-transparent dark:border-slate-800 rounded-xl w-fit overflow-x-auto">
        <button
          type="button"
          onClick={() => setMode('fractions')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
            mode === 'fractions' ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          مختبر الكسور الاعتيادية
        </button>
        <button
          type="button"
          onClick={() => setMode('multiplication')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
            mode === 'multiplication' ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          مصفوفة جدول الضرب والمساحة
        </button>
        <button
          type="button"
          onClick={() => setMode('arabic_letters')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
            mode === 'arabic_letters' ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          مختبر الحروف والحركات والتحليل
        </button>
      </div>

      {/* Mode 1: Fractions */}
      {mode === 'fractions' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl p-6 text-white space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-lg font-bold font-display">تمثيل الكسر بالشكل الدائري والشريطي</h2>
              <span dir="ltr" className="font-mono text-2xl font-extrabold text-sky-300 tabular-nums">
                {safeNumerator} / {denominator}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div className="flex justify-center bg-slate-900 border border-slate-800 rounded-xl p-4">
                <svg width="270" height="270" viewBox="0 0 270 270" role="img" aria-label="نموذج الكسر الدائري">
                  {slicePaths.map((s, idx) => (
                    <path
                      key={idx}
                      d={s.d}
                      fill={s.filled ? '#2563eb' : '#1e293b'}
                      stroke="#0f172a"
                      strokeWidth="2.5"
                    />
                  ))}
                </svg>
              </div>

              <div className="space-y-4">
                <p className="text-xs text-slate-300">شريط الكسر المقسم إلى {denominator} أجزاء متساوية:</p>
                <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${denominator}, minmax(0, 1fr))` }}>
                  {Array.from({ length: denominator }, (_, idx) => (
                    <div
                      key={idx}
                      className={`h-12 rounded-lg border flex items-center justify-center font-mono text-xs font-bold ${
                        idx < safeNumerator
                          ? 'bg-blue-600 border-blue-400 text-white'
                          : 'bg-slate-900 border-slate-700 text-slate-400'
                      }`}
                    >
                      1/{denominator}
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                    <p className="text-[11px] text-slate-400">الصورة العشرية</p>
                    <p dir="ltr" className="font-mono text-lg font-bold text-amber-300 tabular-nums mt-0.5">
                      {decimalValue}
                    </p>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                    <p className="text-[11px] text-slate-400">النسبة المئوية</p>
                    <p dir="ltr" className="font-mono text-lg font-bold text-emerald-300 tabular-nums mt-0.5">
                      {percentValue}%
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">التحكم في البسط والمقام</h3>

            <label className="block space-y-2">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">البسط (الأجزاء المظللة)</span>
                <span className="font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums">{safeNumerator}</span>
              </div>
              <input
                type="range"
                min={0}
                max={denominator}
                value={safeNumerator}
                onChange={(e) => setNumerator(Number(e.target.value))}
                className="w-full accent-blue-700 cursor-pointer"
              />
            </label>

            <label className="block space-y-2">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">المقام (إجمالي الأجزاء المتساوية)</span>
                <span className="font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums">{denominator}</span>
              </div>
              <input
                type="range"
                min={1}
                max={12}
                value={denominator}
                onChange={(e) => {
                  const nextDen = Number(e.target.value);
                  setDenominator(nextDen);
                  if (numerator > nextDen) setNumerator(nextDen);
                }}
                className="w-full accent-blue-700 cursor-pointer"
              />
            </label>

            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              البسط يخبرنا بعدد الأجزاء المختارة، بينما المقام يحدد عدد الأجزاء المتساوية التي قُسّم إليها الواحد الصحيح.
            </div>
          </div>
        </div>
      )}

      {/* Mode 2: Multiplication Array */}
      {mode === 'multiplication' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl p-6 text-white space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-lg font-bold font-display">مصفوفة الضرب والمساحة</h2>
              <span dir="ltr" className="font-mono text-2xl font-extrabold text-amber-300 tabular-nums">
                {rows} × {cols} = {rows * cols}
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 overflow-x-auto">
              <div
                className="grid gap-1.5 mx-auto w-fit"
                style={{ gridTemplateColumns: `repeat(${cols}, 28px)` }}
              >
                {Array.from({ length: rows * cols }, (_, idx) => (
                  <div
                    key={idx}
                    className="w-7 h-7 rounded bg-blue-600 border border-blue-400 flex items-center justify-center text-[10px] font-mono text-blue-100"
                  >
                    {idx + 1}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                <p className="text-[11px] text-slate-400">ناتج الضرب (المساحة)</p>
                <p className="font-mono text-base font-bold text-white tabular-nums mt-1">
                  {rows * cols} وحدة مربعة
                </p>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                <p className="text-[11px] text-slate-400">المحيط</p>
                <p className="font-mono text-base font-bold text-sky-300 tabular-nums mt-1">
                  {2 * (rows + cols)} وحدة طول
                </p>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                <p className="text-[11px] text-slate-400">بالجمع المتكرر</p>
                <p dir="ltr" className="font-mono text-xs font-bold text-amber-300 mt-1.5 truncate">
                  {Array.from({ length: rows }, () => cols).join(' + ')}
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">اختر الصفوف والأعمدة</h3>

            <label className="block space-y-2">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">عدد الصفوف</span>
                <span className="font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums">{rows}</span>
              </div>
              <input
                type="range"
                min={1}
                max={10}
                value={rows}
                onChange={(e) => setRows(Number(e.target.value))}
                className="w-full accent-blue-700 cursor-pointer"
              />
            </label>

            <label className="block space-y-2">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">عدد الأعمدة</span>
                <span className="font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums">{cols}</span>
              </div>
              <input
                type="range"
                min={1}
                max={12}
                value={cols}
                onChange={(e) => setCols(Number(e.target.value))}
                className="w-full accent-blue-700 cursor-pointer"
              />
            </label>

            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              تساعد المصفوفات طلاب الصف الثاني والثالث الابتدائي على فهم جدول الضرب وإيجاد المساحة والمحيط بسهولة.
            </div>
          </div>
        </div>
      )}

      {/* Mode 3: Arabic Letters & Harakat */}
      {mode === 'arabic_letters' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">اختر الحرف للتدريب</h2>
            <div className="grid grid-cols-4 gap-2">
              {ARABIC_LETTERS.map((item, idx) => (
                <button
                  key={item.char}
                  type="button"
                  onClick={() => setLetterIdx(idx)}
                  className={`h-14 rounded-xl border text-xl font-extrabold font-display transition-colors cursor-pointer ${
                    letterIdx === idx
                      ? 'bg-blue-700 border-blue-700 text-white'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {item.char}
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">حرف {activeLetter.name}</p>
                <h2 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-display mt-0.5">
                  أصوات الحرف بالحركات القصيرة
                </h2>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    if (isSpeaking) {
                      speechController.stop();
                      setIsSpeaking(false);
                      return;
                    }
                    const text = `حرف ${activeLetter.name}. بالفتحة: ${activeLetter.fathaWord}. بالضمة: ${activeLetter.dammaWord}. بالكسرة: ${activeLetter.kasraWord}.`;
                    speechController.speak(text, {
                      lang: 'ar-EG',
                      rate: 0.9,
                      onStart: () => setIsSpeaking(true),
                      onEnd: () => setIsSpeaking(false),
                      onError: () => setIsSpeaking(false),
                    });
                  }}
                  className={`inline-flex items-center gap-1.5 px-4 py-2.5 min-h-[40px] text-xs font-semibold rounded-xl cursor-pointer ${
                    isSpeaking
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-blue-700 hover:bg-blue-800 text-white'
                  }`}
                >
                  {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  <span>{isSpeaking ? 'إيقاف الصوت' : 'استمع لنطق الحرف'}</span>
                </button>
                <div className="w-14 h-14 rounded-2xl bg-slate-900 dark:bg-slate-800 text-white flex items-center justify-center text-3xl font-extrabold font-display">
                  {activeLetter.char}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-1">
                <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">بالفتحة ({activeLetter.char}َ)</p>
                <p className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-display">{activeLetter.fathaWord}</p>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-1">
                <p className="text-xs font-semibold text-amber-700 dark:text-amber-400">بالضمة ({activeLetter.char}ُ)</p>
                <p className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-display">{activeLetter.dammaWord}</p>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-1">
                <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">بالكسرة ({activeLetter.char}ِ)</p>
                <p className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-display">{activeLetter.kasraWord}</p>
              </div>
            </div>

            <div className="bg-slate-900 dark:bg-slate-950 border border-transparent dark:border-slate-800 text-white rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-xs text-slate-300">التحليل إلى مقاطع صوتية (مثال):</span>
              <span className="text-lg font-bold font-display text-amber-300">{activeLetter.syllables}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
