import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  Award,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  CreditCard,
  Download,
  FileText,
  History,
  KeyRound,
  Lock,
  Play,
  Printer,
  RotateCcw,
  Star,
  UserCheck,
  Wallet,
  XCircle,
} from 'lucide-react';
import { useAcademy } from '../context/AcademyContext.tsx';
import type { ExamAttempt, Lesson, LessonAttendance, LessonReview } from '../types.ts';
import { BRANCH_LABELS, formatArabicDateTime, formatEgp, GRADE_LABELS } from '../utils/academy.ts';
import { CartoonVideoPlayer } from './CartoonVideoPlayer.tsx';
import { LessonReviewPanel } from './LessonReviewPanel.tsx';

type ClassroomTab = 'formulas' | 'handout' | 'exam';

export function CourseClassroom() {
  const {
    snapshot,
    selectedCourseId,
    currentStudent,
    setActiveSection,
    enrollWithWallet,
    redeemCode,
    createFawryCharge,
    confirmSandboxFawryOrder,
    downloadAuthorizedCurriculum,
    recordAttendance,
    completeLesson,
    submitLessonReview,
    submitExam,
  } = useAcademy();

  const course = useMemo(() => {
    const list = snapshot?.courses || [];
    return list.find((c) => c.id === selectedCourseId) || list[0] || null;
  }, [snapshot?.courses, selectedCourseId]);

  const exam = useMemo(() => {
    if (!course) return null;
    return snapshot?.exams.find((e) => e.id === course.examId) || null;
  }, [snapshot?.exams, course]);

  const [activeLessonId, setActiveLessonId] = useState<string>('');
  const [activeTab, setActiveTab] = useState<ClassroomTab>('formulas');
  const [activationInput, setActivationInput] = useState('');
  const [busyAction, setBusyAction] = useState(false);
  const [resumeTrigger, setResumeTrigger] = useState(0);

  // Interactive Exam State
  const [examStarted, setExamStarted] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [secondsLeft, setSecondsLeft] = useState(900);
  const [examResult, setExamResult] = useState<ExamAttempt | null>(null);
  const [submittingExam, setSubmittingExam] = useState(false);

  useEffect(() => {
    if (course && course.lessons.length > 0) {
      setActiveLessonId(course.lessons[0].id);
      setExamStarted(false);
      setExamResult(null);
      setActiveTab('formulas');
    }
  }, [course?.id]);

  const currentLesson = useMemo(() => {
    if (!course) return null;
    return course.lessons.find((l) => l.id === activeLessonId) || course.lessons[0] || null;
  }, [course, activeLessonId]);

  const isCourseUnlocked = Boolean(
    course && (course.priceEgp === 0 || currentStudent?.enrolledCourseIds.includes(course.id))
  );

  // Strict gating: paid monthly courses do not unlock any lesson before payment
  const canWatchLesson = isCourseUnlocked;

  const activeFawryOrder = useMemo(() => {
    if (!course || !currentStudent) return null;
    return (
      (snapshot?.fawryOrders || []).find(
        (o) =>
          o.studentId === currentStudent.id &&
          o.purpose === 'course' &&
          o.courseId === course.id &&
          o.status === 'UNPAID'
      ) || null
    );
  }, [snapshot?.fawryOrders, course, currentStudent]);

  // Exam timer
  useEffect(() => {
    if (!examStarted || examResult) return;
    const timer = setInterval(() => {
      setSecondsLeft((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [examStarted, examResult]);

  if (!course) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center space-y-3">
        <p className="text-base font-bold text-slate-800 dark:text-slate-100">لم يتم تحديد كورس بعد</p>
        <button
          type="button"
          onClick={() => setActiveSection('catalog')}
          className="px-4 py-2 bg-blue-700 text-white text-xs font-semibold rounded-xl cursor-pointer"
        >
          العودة إلى قائمة الكورسات
        </button>
      </div>
    );
  }

  const attendanceByLessonId = useMemo(() => {
    const map = new Map<string, LessonAttendance>();
    if (!currentStudent || !snapshot?.attendances) return map;
    snapshot.attendances.forEach((att) => {
      if (att.studentId === currentStudent.id) {
        map.set(att.lessonId, att);
      }
    });
    return map;
  }, [currentStudent, snapshot?.attendances]);

  const fullyAttendedCount = course.lessons.filter((l) => {
    const att = attendanceByLessonId.get(l.id);
    return Boolean(att && att.checkedIn && att.fullyWatched);
  }).length;

  const currentAttendance = currentLesson ? attendanceByLessonId.get(currentLesson.id) || null : null;
  const allEightVerified = course.lessons.length > 0 && fullyAttendedCount >= course.lessons.length;

  const resumableCourseLesson = useMemo(() => {
    for (const lesson of course.lessons) {
      const att = attendanceByLessonId.get(lesson.id);
      if (att && typeof att.lastPositionSec === 'number' && att.lastPositionSec > 2 && !att.fullyWatched) {
        return { lesson, att };
      }
    }
    return null;
  }, [course.lessons, attendanceByLessonId]);

  const courseReviews = useMemo<LessonReview[]>(() => {
    return (snapshot?.lessonReviews || []).filter((r) => r.courseId === course.id);
  }, [snapshot?.lessonReviews, course.id]);

  const courseAverageRating = useMemo(() => {
    if (courseReviews.length === 0) return null;
    const sum = courseReviews.reduce((acc, r) => acc + r.overallRating, 0);
    return Number((sum / courseReviews.length).toFixed(1));
  }, [courseReviews]);

  const handleSelectLesson = (lessonId: string) => {
    setActiveLessonId(lessonId);
  };

  const handleCodeUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activationInput.trim()) return;
    setBusyAction(true);
    const ok = await redeemCode(activationInput.trim(), course.id);
    if (ok) setActivationInput('');
    setBusyAction(false);
  };

  const handleWalletEnroll = async () => {
    setBusyAction(true);
    await enrollWithWallet(course.id);
    setBusyAction(false);
  };

  const handleStartExam = () => {
    if (!exam) return;
    setSelectedAnswers(new Array(exam.questions.length).fill(-1));
    setSecondsLeft(exam.durationMin * 60);
    setExamResult(null);
    setExamStarted(true);
  };

  const handleSubmitExam = async () => {
    if (!exam) return;
    setSubmittingExam(true);
    const result = await submitExam(exam.id, selectedAnswers);
    if (result) {
      setExamResult(result);
    }
    setSubmittingExam(false);
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const handlePrintHandout = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-10">
      {/* Course Breadcrumb & Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="space-y-1">
          <button
            type="button"
            onClick={() => setActiveSection(course.grade === 'kg' ? 'kindergarten' : 'catalog')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-700 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 cursor-pointer"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>{course.grade === 'kg' ? 'العودة إلى تأسيس رياض الأطفال' : 'العودة إلى دروس الابتدائي'}</span>
          </button>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-display">
            {course.title}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {GRADE_LABELS[course.grade]} · {BRANCH_LABELS[course.branch]} ·{' '}
            <span className="tabular-nums">خطة الشهر: {course.lessons.length} محاضرات (4 أسابيع)</span> ·{' '}
            <span className="tabular-nums">{course.totalHours} ساعات</span>
            {courseAverageRating !== null && (
              <>
                {' · '}
                <span className="inline-flex items-center gap-1 font-bold text-amber-700 dark:text-amber-400 font-mono tabular-nums">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                  <span>{courseAverageRating}</span>
                  <span className="text-slate-500 dark:text-slate-400 font-sans font-normal">
                    ({courseReviews.length} تقييم)
                  </span>
                </span>
              </>
            )}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {isCourseUnlocked ? (
            <>
              <button
                type="button"
                onClick={() =>
                  void downloadAuthorizedCurriculum({ courseId: course.id, format: 'html' })
                }
                className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تنزيل منهج المادة</span>
              </button>

              <div className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>الكورس والمنهج والامتحان مفعلون</span>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 dark:text-amber-400">
                <Lock className="w-3.5 h-3.5" />
                <span>مغلق لحين السداد</span>
              </span>
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                {formatEgp(course.priceEgp)}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Course Resume Watching Shortcut when another lesson has a saved pause point */}
      {isCourseUnlocked &&
        resumableCourseLesson &&
        resumableCourseLesson.lesson.id !== currentLesson?.id && (
          <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-2xl px-5 py-3.5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-xs text-slate-800 dark:text-slate-100">
              <History className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0" />
              <span>
                لديك نقطة توقف محفوظة في{' '}
                <strong className="font-bold">
                  المحاضرة {resumableCourseLesson.lesson.order}: {resumableCourseLesson.lesson.title}
                </strong>{' '}
                عند الدقيقة{' '}
                <span className="font-mono font-bold text-blue-700 dark:text-blue-300 tabular-nums">
                  {formatTimer(resumableCourseLesson.att.lastPositionSec || 0)}
                </span>
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setActiveLessonId(resumableCourseLesson.lesson.id);
                setResumeTrigger((c) => c + 1);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[36px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl cursor-pointer shrink-0"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>متابعة المشاهدة</span>
            </button>
          </div>
        )}

      {/* Main Two-Zone Classroom Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Theater & Content Zone (65-70%) */}
        <div className="lg:col-span-8 space-y-5">
          {/* Interactive Cartoon Lecture Player or Lock Screen */}
          {canWatchLesson && currentLesson ? (
            <div className="space-y-4">
              <CartoonVideoPlayer
                course={course}
                lesson={currentLesson}
                teacherName={snapshot?.profile.teacherName || 'الأستاذة نجلاء فتحي'}
                currentStudent={currentStudent}
                attendance={currentAttendance}
                resumeTrigger={resumeTrigger}
                onRecordAttendance={recordAttendance}
                onCompleteLesson={completeLesson}
              />

              {/* Lecture Attendance & 8/8 Certificate Verification Strip */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-slate-100">
                      <UserCheck className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                      <span>سجل حضور المحاضرات والتحقق من المشاهدة</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 tabular-nums">
                      المحاضرة الحالية ({currentLesson.order}):{' '}
                      <span className="font-semibold text-slate-900 dark:text-slate-100">
                        {currentAttendance?.fullyWatched
                          ? 'تم تسجيل الحضور والمشاهدة الكاملة (100%)'
                          : currentAttendance?.checkedIn
                            ? `تم تسجيل الحضور · المشاهدة المسجلة ${currentAttendance.watchedPercent}% (المطلوب 90%)`
                            : 'بانتظار تسجيل الحضور وبدء المشاهدة'}
                      </span>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {!currentStudent ? (
                      <button
                        type="button"
                        onClick={() => setActiveSection('student')}
                        className="px-4 py-2 min-h-[38px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-xl cursor-pointer"
                      >
                        سجل الدخول لحفظ حضورك
                      </button>
                    ) : !currentAttendance?.checkedIn ? (
                      <button
                        type="button"
                        onClick={() =>
                          void recordAttendance({
                            lessonId: currentLesson.id,
                            watchedPercent: currentAttendance?.watchedPercent || 1,
                            watchedSeconds: currentAttendance?.watchedSeconds || 0,
                            checkedIn: true,
                          })
                        }
                        className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl cursor-pointer"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>تسجيل حضور المحاضرة الآن</span>
                      </button>
                    ) : allEightVerified ? (
                      <button
                        type="button"
                        onClick={() => setActiveSection('student')}
                        className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl cursor-pointer"
                      >
                        <Award className="w-3.5 h-3.5" />
                        <span>تحميل الشهادة PDF من صفحة الطالب</span>
                      </button>
                    ) : (
                      <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>حضورك مسجل على السجل</span>
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <span className="text-slate-600 dark:text-slate-300">
                    {allEightVerified
                      ? 'تم التحقق من حضور ومشاهدة جميع الـ 8 محاضرات كاملة — يمكنك تحميل شهادتك PDF الآن.'
                      : `شرط تحميل شهادة الإتمام PDF: تسجيل حضور ومشاهدة الـ ${course.lessons.length} محاضرات كاملة (متبقي ${Math.max(0, course.lessons.length - fullyAttendedCount)}).`}
                  </span>
                  <span className="font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums shrink-0">
                    الحضور المعتمد: {fullyAttendedCount} / {course.lessons.length}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            /* Locked Course Payment Gate */
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 shrink-0">
                  <Lock className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 font-display">
                    الكورس الشهري مغلق — ادفع أولاً لفتح الدروس والمنهج والامتحان
                  </h2>
                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    لا يتم فتح محاضرات الكورس الشهري أو تحميل الملازم والمنهج أو دخول الامتحان الإلكتروني إلا بعد سداد قيمة الاشتراك ({formatEgp(course.priceEgp)}) عبر فوري باي أو المحفظة أو كود السنتر.
                  </p>
                </div>
              </div>

              {/* Primary Payment Method: FawryPay */}
              <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-sm font-bold">
                    <CreditCard className="w-4 h-4 text-amber-400" />
                    <span>الدفع الإلكتروني عبر فوري باي (FawryPay)</span>
                  </div>
                  <span className="text-xs text-slate-300 font-mono tabular-nums">
                    {snapshot?.fawryStatus.mode === 'live'
                      ? 'بوابة فوري المباشرة (Live)'
                      : 'بوابة فوري باي (وضع التجربة Sandbox)'}
                  </span>
                </div>

                {activeFawryOrder ? (
                  <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="text-xs text-slate-300">الرقم المرجعي للدفع في فوري:</p>
                        <p
                          dir="ltr"
                          className="text-2xl font-extrabold font-mono text-amber-400 tracking-wider tabular-nums mt-0.5"
                        >
                          {activeFawryOrder.referenceNumber}
                        </p>
                      </div>
                      <div className="text-left">
                        <p className="text-xs text-slate-300">المبلغ المطلوب</p>
                        <p className="text-lg font-bold text-white tabular-nums">
                          {formatEgp(activeFawryOrder.amountEgp)}
                        </p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      سدد هذا الرقم في أي ماكينة فوري أو من تطبيق myFawry (خدمة فوري باي). بمجرد السداد يصل إشعار تلقائي من فوري ويُفتح لك الكورس والمنهج والامتحان فوراً. صالحة حتى{' '}
                      <span className="font-mono">{formatArabicDateTime(activeFawryOrder.expiresAt)}</span>.
                    </p>

                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      {activeFawryOrder.mode === 'sandbox' && (
                        <button
                          type="button"
                          disabled={busyAction}
                          onClick={async () => {
                            setBusyAction(true);
                            await confirmSandboxFawryOrder(activeFawryOrder.id);
                            setBusyAction(false);
                          }}
                          className="px-4 py-2.5 min-h-[40px] bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                        >
                          تأكيد الدفع عبر فوري (محاكاة السداد التجريبي)
                        </button>
                      )}
                      <button
                        type="button"
                        disabled={busyAction}
                        onClick={async () => {
                          setBusyAction(true);
                          await createFawryCharge({ purpose: 'course', courseId: course.id });
                          setBusyAction(false);
                        }}
                        className="px-4 py-2.5 min-h-[40px] bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-xl cursor-pointer"
                      >
                        إصدار رقم مرجعي جديد
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <p className="text-xs text-slate-300 leading-relaxed max-w-xl">
                      احصل على كود دفع فوري باي فوري لسداد رسوم الكورس ({formatEgp(course.priceEgp)}) من أي منفذ فوري أو بالبطاقة ليُفتح الكورس مباشرة لحسابك.
                    </p>
                    <button
                      type="button"
                      disabled={busyAction}
                      onClick={async () => {
                        setBusyAction(true);
                        await createFawryCharge({ purpose: 'course', courseId: course.id });
                        setBusyAction(false);
                      }}
                      className="px-5 py-3 min-h-[42px] bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      ادفع الآن عبر فوري باي ({formatEgp(course.priceEgp)})
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Option 2: Activation Code */}
                <form
                  onSubmit={(e) => void handleCodeUnlock(e)}
                  className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-3"
                >
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-slate-100">
                    <KeyRound className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                    <span>تفعيل بكود السنتر</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    أدخل كود الاشتراك الخاص بهذا الكورس (أو كود <span className="font-mono font-bold text-blue-700 dark:text-blue-400">QEMA-VIP-2026</span>).
                  </p>
                  <input
                    type="text"
                    dir="ltr"
                    value={activationInput}
                    onChange={(e) => setActivationInput(e.target.value.toUpperCase())}
                    placeholder="أدخل كود التفعيل"
                    className="w-full px-3 py-2.5 min-h-[42px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm font-mono focus:outline-none focus:border-blue-700"
                  />
                  <button
                    type="submit"
                    disabled={busyAction}
                    className="w-full py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                  >
                    تفعيل الكورس بالكود
                  </button>
                </form>

                {/* Option 3: Wallet Balance */}
                <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-5 flex flex-col justify-between space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-slate-100">
                      <Wallet className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                      <span>الاشتراك من رصيد المحفظة</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      سعر الكورس: <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums">{formatEgp(course.priceEgp)}</span>
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      رصيدك الحالي:{' '}
                      <span className="font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
                        {currentStudent ? `${currentStudent.walletBalance} ج.م` : 'غير مسجل الدخول'}
                      </span>
                    </p>
                  </div>

                  <button
                    type="button"
                    disabled={busyAction}
                    onClick={() => void handleWalletEnroll()}
                    className="w-full py-2.5 min-h-[42px] bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-600 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                  >
                    {currentStudent ? `خصم ${course.priceEgp} ج.م وفتح الكورس` : 'تسجيل الدخول للاشتراك'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Classroom Secondary Tabs: Formulas / Printable Handout / Electronic Exam */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="flex items-center gap-1 p-2 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
              <button
                type="button"
                onClick={() => setActiveTab('formulas')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  activeTab === 'formulas'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                ملخص القوانين والشرح
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('handout')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  activeTab === 'handout'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                ملزمة المحاضرة (PDF)
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('exam')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  activeTab === 'exam'
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                الامتحان الإلكتروني ({exam?.questions.length || 0} أسئلة)
              </button>
            </div>

            <div className="p-6">
              {activeTab === 'formulas' && currentLesson && (
                isCourseUnlocked ? (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">
                        ملخص المحاضرة: {currentLesson.title}
                      </h3>
                      <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mt-1">
                        {currentLesson.videoSummary}
                      </p>
                    </div>

                    <div className="space-y-2 pt-2">
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-200">أهم القواعد والمفاهيم:</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {currentLesson.keyFormulas.map((formula, idx) => (
                          <div
                            key={idx}
                            dir="auto"
                            className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 font-mono text-xs sm:text-sm text-slate-900 dark:text-slate-100"
                          >
                            {formula}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-5 flex items-center gap-3 text-xs text-amber-900 dark:text-amber-200">
                    <Lock className="w-4 h-4 shrink-0" />
                    <span>ملخص القواعد والشرح مغلق — يجب دفع قيمة الكورس الشهري أولاً لفتح محتوى الدرس.</span>
                  </div>
                )
              )}

              {activeTab === 'handout' && currentLesson && (
                <div className="space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <FileText className="w-5 h-5 text-blue-700 dark:text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">
                          {currentLesson.handoutTitle}
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{currentLesson.handoutSummary}</p>
                      </div>
                    </div>

                    {isCourseUnlocked && (
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            void downloadAuthorizedCurriculum({ courseId: course.id, format: 'html' })
                          }
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-xl whitespace-nowrap cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>تنزيل المنهج كاملاً</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            void downloadAuthorizedCurriculum({ courseId: course.id, format: 'doc' })
                          }
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 text-xs font-semibold rounded-xl whitespace-nowrap cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>ملف Word</span>
                        </button>
                        <button
                          type="button"
                          onClick={handlePrintHandout}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 dark:hover:bg-slate-600 text-white text-xs font-semibold rounded-xl whitespace-nowrap cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>طباعة PDF</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {isCourseUnlocked ? (
                    <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3 text-xs text-slate-500 dark:text-slate-400">
                        <span>{snapshot?.profile.platformName || 'منصة الأستاذة نجلاء فتحي'} · {GRADE_LABELS[course.grade]}</span>
                        <span>إعداد: {snapshot?.profile.teacherName || 'الأستاذة نجلاء فتحي'}</span>
                      </div>
                      {currentLesson.slides.map((s, i) => (
                        <div key={i} className="space-y-1.5">
                          <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                            {i + 1}. {s.heading}
                          </p>
                          <p dir="auto" className="font-mono text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-blue-800 dark:text-blue-300">
                            {s.formula}
                          </p>
                          <p className="text-xs text-slate-600 dark:text-slate-300">{s.note}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-amber-900 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-5 flex items-center gap-3">
                      <Lock className="w-4 h-4 shrink-0" />
                      <span>الملزمة وتنزيل المنهج مغلقان — ادفع قيمة الكورس الشهري أولاً لفتح جميع الملازم وتنزيل المنهج.</span>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'exam' && exam && (
                !isCourseUnlocked ? (
                  <div className="text-xs text-amber-900 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-5 flex items-center gap-3">
                    <Lock className="w-4 h-4 shrink-0" />
                    <span>الامتحان الإلكتروني مغلق — يجب دفع قيمة الكورس الشهري أو تفعيله أولاً لفتح الاختبار ورصد الدرجات.</span>
                  </div>
                ) : (
                <div className="space-y-5">
                  {!examStarted ? (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-5">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-base font-bold text-slate-900 dark:text-slate-100 font-display">
                          <ClipboardCheck className="w-5 h-5 text-blue-700 dark:text-blue-400" />
                          <span>{exam.title}</span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-300">
                          عدد الأسئلة: <span className="font-bold tabular-nums">{exam.questions.length}</span> ·
                          المدة المحددة: <span className="font-bold tabular-nums">{exam.durationMin} دقيقة</span> ·
                          درجة النجاح: <span className="font-bold tabular-nums">{exam.passingScore}%</span>
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={handleStartExam}
                        className="px-5 py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        ابدأ الامتحان الآن
                      </button>
                    </div>
                  ) : examResult ? (
                    /* Exam Results & Step-by-Step Model Answer */
                    <div className="space-y-5">
                      <div
                        className={`rounded-xl p-5 border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                          examResult.passed
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                            : 'bg-amber-50 border-amber-200 text-amber-950'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Award className="w-7 h-7 shrink-0" />
                          <div>
                            <p className="text-base font-extrabold font-display">
                              النتيجة: {examResult.score} من {examResult.total} ({examResult.percentage}%) —{' '}
                              {examResult.passed ? 'اجتزت الاختبار بنجاح' : 'تحتاج إلى مراجعة'}
                            </p>
                            <p className="text-xs opacity-80 mt-0.5">
                              تم حفظ النتيجة في سجل درجات الطالب ومراجعة الإجابات بالأسفل.
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleStartExam}
                          className="inline-flex items-center gap-1.5 px-4 py-2 bg-white border border-slate-300 text-slate-900 text-xs font-semibold rounded-xl shrink-0 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>إعادة الاختبار</span>
                        </button>
                      </div>

                      <div className="space-y-4">
                        {exam.questions.map((q, qIdx) => {
                          const userAns = examResult.answers[qIdx];
                          const isCorrect = userAns === q.correctIndex;
                          return (
                            <div key={q.id} className="border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-2.5">
                              <div className="flex items-start justify-between gap-3">
                                <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                                  {qIdx + 1}. {q.prompt}
                                </p>
                                <span
                                  className={`inline-flex items-center gap-1 text-xs font-semibold shrink-0 ${
                                    isCorrect ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'
                                  }`}
                                >
                                  {isCorrect ? (
                                    <>
                                      <CheckCircle2 className="w-4 h-4" />
                                      <span>إجابة صحيحة</span>
                                    </>
                                  ) : (
                                    <>
                                      <XCircle className="w-4 h-4" />
                                      <span>إجابة خاطئة</span>
                                    </>
                                  )}
                                </span>
                              </div>

                              <p className="text-xs text-slate-600 dark:text-slate-300">
                                إجابتك:{' '}
                                <span className="font-semibold text-slate-900 dark:text-slate-100">
                                  {userAns >= 0 ? q.options[userAns] : 'لم يتم الاختيار'}
                                </span>{' '}
                                · الإجابة الصحيحة:{' '}
                                <span className="font-semibold text-emerald-700 dark:text-emerald-400">{q.options[q.correctIndex]}</span>
                              </p>

                              <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-3 text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                                <span className="font-bold text-slate-900 dark:text-slate-100">خطوات الحل: </span>
                                {q.explanation}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    /* Active Exam Questions */
                    <div className="space-y-6">
                      <div className="flex items-center justify-between bg-slate-900 dark:bg-slate-950 text-white rounded-xl px-4 py-3 text-xs">
                        <span className="font-bold">{exam.title}</span>
                        <span className="inline-flex items-center gap-1.5 font-mono font-bold tabular-nums text-amber-300">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{formatTimer(secondsLeft)}</span>
                        </span>
                      </div>

                      <div className="space-y-5">
                        {exam.questions.map((q, qIdx) => (
                          <div key={q.id} className="border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-3">
                            <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                              {qIdx + 1}. {q.prompt}
                            </p>
                            {q.formula && (
                              <div dir="ltr" className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 font-mono text-xs text-slate-800 dark:text-slate-100 inline-block">
                                {q.formula}
                              </div>
                            )}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                              {q.options.map((opt, oIdx) => {
                                const selected = selectedAnswers[qIdx] === oIdx;
                                return (
                                  <button
                                    key={oIdx}
                                    type="button"
                                    onClick={() => {
                                      setSelectedAnswers((prev) => {
                                        const next = [...prev];
                                        next[qIdx] = oIdx;
                                        return next;
                                      });
                                    }}
                                    className={`text-right px-4 py-3 rounded-xl border text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                                      selected
                                        ? 'bg-blue-700 border-blue-700 text-white'
                                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-700'
                                    }`}
                                  >
                                    {opt}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          type="button"
                          onClick={() => setExamStarted(false)}
                          className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
                        >
                          إلغاء
                        </button>
                        <button
                          type="button"
                          disabled={submittingExam}
                          onClick={() => void handleSubmitExam()}
                          className="px-6 py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl cursor-pointer"
                        >
                          {submittingExam ? 'جاري التصحيح...' : 'تسليم الإجابات وعرض الدرجة'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                )
              )}
            </div>
          </div>

          {/* Extracted Post-Completion Lesson Rating & Student Reviews Sub-component */}
          {currentLesson && (
            <LessonReviewPanel
              course={course}
              lesson={currentLesson}
              currentStudent={currentStudent}
              isCourseUnlocked={isCourseUnlocked}
              attendance={currentAttendance}
              reviews={snapshot?.lessonReviews || []}
              onSubmitReview={submitLessonReview}
              onGoToStudentLogin={() => setActiveSection('student')}
            />
          )}
        </div>

        {/* Sidebar Curriculum Deck (30-35%) */}
        <aside className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">خطة الشهر · سجل الحضور (8 محاضرات)</h2>
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                {fullyAttendedCount}/{course.lessons.length}
              </span>
            </div>
            <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-700 transition-all"
                style={{
                  width: `${
                    course.lessons.length > 0
                      ? Math.round((fullyAttendedCount / course.lessons.length) * 100)
                      : 0
                  }%`,
                }}
              />
            </div>
          </div>

          <div className="space-y-4">
            {(() => {
              const weekLabels: Record<number, string> = {
                1: 'الأسبوع الأول',
                2: 'الأسبوع الثاني',
                3: 'الأسبوع الثالث',
                4: 'الأسبوع الرابع',
              };
              const groups = new Map<number, Lesson[]>();
              course.lessons.forEach((lesson) => {
                const wk = lesson.weekNumber || Math.ceil(lesson.order / 2);
                const bucket = groups.get(wk) || [];
                bucket.push(lesson);
                groups.set(wk, bucket);
              });
              return Array.from(groups.entries()).map(([wk, weekLessons]) => (
                <div key={wk} className="space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 dark:text-slate-400 px-1">
                    <span>{weekLabels[wk] || `الأسبوع ${wk}`}</span>
                    <span className="tabular-nums">{weekLessons.length} محاضرات كرتونية</span>
                  </div>
                  <div className="space-y-2">
                    {weekLessons.map((lesson) => {
                      const isSelected = lesson.id === currentLesson?.id;
                      const att = attendanceByLessonId.get(lesson.id);
                      const isAttendedFull = Boolean(att && att.checkedIn && att.fullyWatched);
                      const isCheckedInOnly = Boolean(att && att.checkedIn && !att.fullyWatched);
                      const isLessonOpen = isCourseUnlocked;
                      const hasSavedPause = Boolean(
                        att && typeof att.lastPositionSec === 'number' && att.lastPositionSec > 2 && !isAttendedFull
                      );

                      return (
                        <button
                          key={lesson.id}
                          type="button"
                          onClick={() => handleSelectLesson(lesson.id)}
                          className={`w-full text-right p-3.5 rounded-xl border transition-colors flex items-start justify-between gap-3 cursor-pointer ${
                            isSelected
                              ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-700 text-slate-900 dark:text-slate-100'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                          }`}
                        >
                          <div className="space-y-1 min-w-0">
                            <p className="text-xs font-bold leading-snug">
                              {lesson.order}. {lesson.title}
                            </p>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                              {lesson.durationMin} دقيقة ·{' '}
                              {isAttendedFull
                                ? 'حاضر ومشاهد بالكامل'
                                : hasSavedPause
                                  ? `متابعة من ${formatTimer(att?.lastPositionSec || 0)}`
                                  : isCheckedInOnly
                                    ? `تم الحضور · ${att?.watchedPercent || 0}% مشاهدة`
                                    : isLessonOpen
                                      ? 'فيديو كرتوني · بانتظار الحضور'
                                      : 'مغلقة حتى السداد'}
                            </p>
                          </div>

                          <span className="shrink-0 mt-0.5">
                            {isAttendedFull ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                            ) : isLessonOpen ? (
                              <Play className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                            ) : (
                              <Lock className="w-4 h-4 text-slate-400" />
                            )}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ));
            })()}
          </div>

          {exam && (
            <button
              type="button"
              onClick={() => {
                setActiveTab('exam');
                if (isCourseUnlocked) {
                  handleStartExam();
                } else {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              className={`w-full py-3 px-4 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                isCourseUnlocked
                  ? 'bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
              }`}
            >
              {isCourseUnlocked ? (
                <>
                  <ClipboardCheck className="w-4 h-4" />
                  <span>دخول امتحان تقييم الكورس</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>الامتحان مغلق (ادفع لفتح الامتحان)</span>
                </>
              )}
            </button>
          )}
        </aside>
      </div>
    </div>
  );
}
