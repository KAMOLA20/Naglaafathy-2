import { useEffect, useRef } from 'react';
import type { SubjectBranch } from '../types.ts';

interface AnimatedCartoonStageProps {
  branch: SubjectBranch;
  isPlaying: boolean;
  isSpeaking: boolean;
  speed: number;
  sceneProgress: number; // 0..1 within current scene
  sceneIndex: number;
}

interface FloatingProp {
  xRatio: number;
  yRatio: number;
  text: string;
  phase: number;
  amp: number;
  scale: number;
}

interface ChalkSpark {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
}

function getThemePalette(branch: SubjectBranch) {
  if (branch === 'math' || branch === 'kg_math') {
    return {
      wallTop: '#e0f2fe',
      wallBottom: '#bae6fd',
      wainscot: '#7dd3fc',
      hijabMain: '#1d4ed8',
      hijabDark: '#1e3a8a',
      hijabHighlight: '#60a5fa',
      blazerMain: '#0f172a',
      blazerTrim: '#38bdf8',
      accentColor: '#f59e0b',
      props: ['١ + ٢', '△', '◯', '٤ × ٥', '÷', '□'],
    };
  }
  if (branch === 'kg_english' || branch === 'kg_discover') {
    return {
      wallTop: '#fef3c7',
      wallBottom: '#fde68a',
      wainscot: '#fcd34d',
      hijabMain: '#be185d',
      hijabDark: '#831843',
      hijabHighlight: '#f472b6',
      blazerMain: '#1e293b',
      blazerTrim: '#fbbf24',
      accentColor: '#0284c7',
      props:
        branch === 'kg_english'
          ? ['Aa', 'Bb', 'Cc', '★', '♪', 'ABC']
          : ['☀', '🌱', '★', '☁', '💧', '🌍'],
    };
  }
  return {
    wallTop: '#ecfdf5',
    wallBottom: '#d1fae5',
    wainscot: '#a7f3d0',
    hijabMain: '#047857',
    hijabDark: '#064e3b',
    hijabHighlight: '#34d399',
    blazerMain: '#1e293b',
    blazerTrim: '#fbbf24',
    accentColor: '#2563eb',
    props: ['أ', 'ب', 'ت', 'ج', 'ض', '📖'],
  };
}

export function AnimatedCartoonStage({
  branch,
  isPlaying,
  isSpeaking,
  speed,
  sceneProgress,
  sceneIndex,
}: AnimatedCartoonStageProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stateRef = useRef({
    branch,
    isPlaying,
    isSpeaking,
    speed,
    sceneProgress,
    sceneIndex,
  });

  stateRef.current = { branch, isPlaying, isSpeaking, speed, sceneProgress, sceneIndex };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let timeSec = 0;
    let lastTs = performance.now();
    const sparks: ChalkSpark[] = [];

    const floatingProps: FloatingProp[] = [
      { xRatio: 0.72, yRatio: 0.13, text: '0', phase: 0.2, amp: 7, scale: 1 },
      { xRatio: 0.89, yRatio: 0.11, text: '1', phase: 1.4, amp: 8, scale: 0.95 },
      { xRatio: 0.94, yRatio: 0.34, text: '2', phase: 2.3, amp: 6, scale: 0.9 },
      { xRatio: 0.69, yRatio: 0.28, text: '3', phase: 3.6, amp: 6, scale: 0.85 },
    ];

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.round(rect.width * dpr);
      const targetH = Math.round(rect.height * dpr);
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const drawRoundedRect = (
      x: number,
      y: number,
      w: number,
      h: number,
      r: number,
      fill?: string,
      stroke?: string,
      lineWidth = 2
    ) => {
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, r);
      if (fill) {
        ctx.fillStyle = fill;
        ctx.fill();
      }
      if (stroke) {
        ctx.strokeStyle = stroke;
        ctx.lineWidth = lineWidth;
        ctx.stroke();
      }
    };

    const renderFrame = (now: number) => {
      const dt = Math.min(0.05, Math.max(0.001, (now - lastTs) / 1000));
      lastTs = now;

      const {
        branch: curBranch,
        isPlaying: playing,
        isSpeaking: speaking,
        speed: curSpeed,
        sceneProgress: sProg,
        sceneIndex: sIdx,
      } = stateRef.current;

      timeSec += dt * (playing ? Math.max(1, curSpeed) : 0.65);

      const palette = getThemePalette(curBranch);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = canvas.width / dpr;
      const h = canvas.height / dpr;

      if (w > 0 && h > 0) {
        ctx.save();
        ctx.scale(dpr, dpr);

        // Normalize coordinates onto a virtual 960 x 520 widescreen stage
        const sx = w / 960;
        const sy = h / 520;
        ctx.scale(sx, sy);

        const W = 960;
        const H = 520;

        // 1. Classroom Wall Background
        const wallGrad = ctx.createLinearGradient(0, 0, 0, H);
        wallGrad.addColorStop(0, palette.wallTop);
        wallGrad.addColorStop(0.78, palette.wallBottom);
        wallGrad.addColorStop(1, '#f8fafc');
        ctx.fillStyle = wallGrad;
        ctx.fillRect(0, 0, W, H);

        // Lower wooden classroom paneling
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(0, 398, W, 122);
        ctx.fillStyle = palette.wainscot;
        ctx.fillRect(0, 392, W, 8);

        // 2. Classroom Window on the far right (sun + drifting cartoon clouds)
        const winX = 815;
        const winY = 46;
        const winW = 112;
        const winH = 148;
        drawRoundedRect(winX, winY, winW, winH, 12, '#7dd3fc', '#94a3b8', 5);

        ctx.save();
        ctx.beginPath();
        ctx.roundRect(winX + 4, winY + 4, winW - 8, winH - 8, 9);
        ctx.clip();

        const skyGrad = ctx.createLinearGradient(0, winY, 0, winY + winH);
        skyGrad.addColorStop(0, '#38bdf8');
        skyGrad.addColorStop(1, '#bae6fd');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(winX, winY, winW, winH);

        // Animated Sun in window
        const sunPulse = 1 + Math.sin(timeSec * 2) * 0.06;
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(winX + 26, winY + 28, 13 * sunPulse, 0, Math.PI * 2);
        ctx.fill();

        // Drifting Cartoon Clouds
        const cloud1X = winX + ((timeSec * 14) % (winW + 60)) - 35;
        const cloud2X = winX + (((timeSec * 9) + 55) % (winW + 60)) - 35;
        const drawCloud = (cx: number, cy: number, sc: number) => {
          ctx.fillStyle = 'rgba(255,255,255,0.92)';
          ctx.beginPath();
          ctx.arc(cx, cy, 10 * sc, 0, Math.PI * 2);
          ctx.arc(cx + 10 * sc, cy - 3 * sc, 12 * sc, 0, Math.PI * 2);
          ctx.arc(cx + 21 * sc, cy, 9 * sc, 0, Math.PI * 2);
          ctx.fill();
        };
        drawCloud(cloud1X, winY + 52, 0.9);
        drawCloud(cloud2X, winY + 95, 0.72);

        // Distant green hills
        ctx.fillStyle = '#4ade80';
        ctx.beginPath();
        ctx.ellipse(winX + 32, winY + winH + 5, 55, 28, 0, 0, Math.PI * 2);
        ctx.ellipse(winX + 95, winY + winH + 8, 52, 24, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Window crossbars
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(winX + winW / 2, winY);
        ctx.lineTo(winX + winW / 2, winY + winH);
        ctx.moveTo(winX, winY + winH / 2);
        ctx.lineTo(winX + winW, winY + winH / 2);
        ctx.stroke();

        // 3. Animated Classroom Wall Clock (above teacher)
        const clkX = 695;
        const clkY = 74;
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(clkX, clkY, 26, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Clock ticks & moving hands
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        const minAngle = timeSec * (playing ? 0.8 : 0.15) - Math.PI / 2;
        const hrAngle = minAngle / 12 + 0.7;
        ctx.beginPath();
        ctx.moveTo(clkX, clkY);
        ctx.lineTo(clkX + Math.cos(hrAngle) * 12, clkY + Math.sin(hrAngle) * 12);
        ctx.stroke();
        ctx.strokeStyle = palette.accentColor;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(clkX, clkY);
        ctx.lineTo(clkX + Math.cos(minAngle) * 18, clkY + Math.sin(minAngle) * 18);
        ctx.stroke();
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(clkX, clkY, 3, 0, Math.PI * 2);
        ctx.fill();

        // 4. Swaying Classroom Bunting Flags along the top
        const flagColors = ['#f59e0b', '#2563eb', '#10b981', '#ec4899', '#8b5cf6'];
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(618, 12);
        ctx.quadraticCurveTo(780, 28, 952, 10);
        ctx.stroke();

        for (let i = 0; i < 8; i++) {
          const fx = 638 + i * 39;
          const fy = 15 + Math.sin((i / 7) * Math.PI) * 9;
          const sway = Math.sin(timeSec * 2.2 + i * 0.7) * 3;
          ctx.fillStyle = flagColors[i % flagColors.length];
          ctx.beginPath();
          ctx.moveTo(fx - 10, fy);
          ctx.lineTo(fx + 10, fy);
          ctx.lineTo(fx + sway, fy + 20);
          ctx.closePath();
          ctx.fill();
        }

        // 5. Classroom Chalkboard Frame (Left 61% of frame: x 24..604, y 28..440)
        // Outer wooden frame
        drawRoundedRect(24, 28, 580, 412, 18, '#92400e', '#78350f', 3);
        // Inner dark slate green chalkboard
        const boardGrad = ctx.createLinearGradient(36, 40, 592, 428);
        boardGrad.addColorStop(0, '#0f3327');
        boardGrad.addColorStop(1, '#164535');
        drawRoundedRect(38, 42, 552, 384, 10, undefined, '#064e3b', 2);
        ctx.fillStyle = boardGrad;
        ctx.fill();

        // Subtle chalk dust smudge texture on chalkboard
        ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
        ctx.beginPath();
        ctx.ellipse(240, 210, 140, 65, -0.15, 0, Math.PI * 2);
        ctx.fill();

        // Wooden Chalk Tray + Colored Chalks + Eraser
        drawRoundedRect(60, 434, 498, 16, 6, '#b45309', '#78350f', 2);
        drawRoundedRect(105, 427, 42, 9, 3, '#334155', '#0f172a', 1.5); // Eraser base
        drawRoundedRect(105, 433, 42, 4, 2, '#94a3b8'); // Felt pad
        drawRoundedRect(180, 430, 24, 5, 2, '#ffffff');
        drawRoundedRect(212, 430, 24, 5, 2, '#fde047');
        drawRoundedRect(244, 430, 22, 5, 2, '#f9a8d4');

        // 6. Floating Animated Subject Props around the teacher
        floatingProps.forEach((p, idx) => {
          const px = p.xRatio * W;
          const py = p.yRatio * H + Math.sin(timeSec * 1.9 + p.phase) * p.amp * (playing ? 1.3 : 0.6);
          const tilt = Math.sin(timeSec * 1.4 + p.phase) * 0.08;
          const label = palette.props[(idx + sIdx) % palette.props.length];

          ctx.save();
          ctx.translate(px, py);
          ctx.rotate(tilt);
          drawRoundedRect(-24, -18, 48, 36, 10, 'rgba(255,255,255,0.9)', '#cbd5e1', 1.5);
          ctx.fillStyle = idx % 2 === 0 ? palette.accentColor : palette.hijabMain;
          ctx.font = 'bold 17px Cairo, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(label, 0, 1);
          ctx.restore();
        });

        // 7. Teacher Desk & Potted Plant on bottom-right
        // Plant pot with gently swaying leaves
        const potX = 876;
        const potY = 398;
        for (let l = -1; l <= 1; l++) {
          const leafSway = Math.sin(timeSec * 1.8 + l) * 4;
          ctx.fillStyle = l === 0 ? '#16a34a' : '#22c55e';
          ctx.beginPath();
          ctx.ellipse(potX + l * 11 + leafSway, potY - 22, 9, 20, l * 0.35 + leafSway * 0.02, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.fillStyle = '#ea580c';
        ctx.beginPath();
        ctx.moveTo(potX - 18, potY);
        ctx.lineTo(potX + 18, potY);
        ctx.lineTo(potX + 13, potY + 34);
        ctx.lineTo(potX - 13, potY + 34);
        ctx.closePath();
        ctx.fill();
        drawRoundedRect(potX - 21, potY - 6, 42, 9, 4, '#c2410c');

        // 8. ANIMATED 2D CARTOON TEACHER: الأستاذة نجلاء فتحي (standing at x ~ 758)
        const baseX = 758;
        const baseY = 472;
        const talkSpeed = playing ? 9.5 : 1.5;
        const breathe = Math.sin(timeSec * (playing ? 3.2 : 1.8)) * 3.5;
        const talkBounce = playing ? Math.abs(Math.sin(timeSec * 5.2)) * 4 : 0;
        const bodyY = baseY - breathe - talkBounce;
        const headNod = playing ? Math.sin(timeSec * 3.8) * 0.055 : Math.sin(timeSec * 1.1) * 0.015;

        // Soft floor shadow
        ctx.fillStyle = 'rgba(15, 23, 42, 0.14)';
        ctx.beginPath();
        ctx.ellipse(baseX, 488, 72, 13, 0, 0, Math.PI * 2);
        ctx.fill();

        // Swaying Hijab back drape
        const scarfSway = Math.sin(timeSec * 2.5) * (playing ? 6 : 2);
        ctx.fillStyle = palette.hijabDark;
        ctx.beginPath();
        ctx.moveTo(baseX - 42, bodyY - 205);
        ctx.quadraticCurveTo(baseX - 68 + scarfSway, bodyY - 120, baseX - 52 + scarfSway, bodyY - 58);
        ctx.lineTo(baseX + 52, bodyY - 58);
        ctx.quadraticCurveTo(baseX + 64 + scarfSway * 0.5, bodyY - 125, baseX + 42, bodyY - 205);
        ctx.closePath();
        ctx.fill();

        // Torso / Modest Tunic & Blazer
        // Inner white/cream blouse
        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.moveTo(baseX - 52, bodyY - 122);
        ctx.lineTo(baseX + 52, bodyY - 122);
        ctx.lineTo(baseX + 68, bodyY + 12);
        ctx.lineTo(baseX - 68, bodyY + 12);
        ctx.closePath();
        ctx.fill();

        // Blazer left & right panels
        ctx.fillStyle = palette.blazerMain;
        ctx.beginPath();
        ctx.moveTo(baseX - 54, bodyY - 124);
        ctx.quadraticCurveTo(baseX - 18, bodyY - 115, baseX - 10, bodyY + 12);
        ctx.lineTo(baseX - 70, bodyY + 12);
        ctx.quadraticCurveTo(baseX - 66, bodyY - 65, baseX - 54, bodyY - 124);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(baseX + 54, bodyY - 124);
        ctx.quadraticCurveTo(baseX + 18, bodyY - 115, baseX + 10, bodyY + 12);
        ctx.lineTo(baseX + 70, bodyY + 12);
        ctx.quadraticCurveTo(baseX + 66, bodyY - 65, baseX + 54, bodyY - 124);
        ctx.fill();

        // Golden teacher badge pin
        ctx.fillStyle = palette.blazerTrim;
        ctx.beginPath();
        ctx.arc(baseX + 34, bodyY - 76, 6, 0, Math.PI * 2);
        ctx.fill();

        // Right arm (viewer's right) holding an open colorful lesson book, gently bobbing
        const bookBob = Math.sin(timeSec * 2.7) * (playing ? 5 : 1.5);
        ctx.save();
        ctx.translate(baseX + 58, bodyY - 108);
        ctx.rotate(-0.18 + Math.sin(timeSec * 2.2) * 0.05);
        drawRoundedRect(-12, 0, 24, 62, 12, palette.blazerMain);
        // Cartoon hand
        ctx.fillStyle = '#fbd3b6';
        ctx.beginPath();
        ctx.arc(0, 66, 13, 0, Math.PI * 2);
        ctx.fill();
        // Open Lesson Book
        ctx.translate(-10, 52 + bookBob * 0.3);
        ctx.rotate(0.2);
        drawRoundedRect(-26, -18, 52, 34, 5, '#2563eb', '#1e3a8a', 2);
        drawRoundedRect(-21, -14, 19, 26, 2, '#ffffff');
        drawRoundedRect(2, -14, 19, 26, 2, '#f8fafc');
        ctx.restore();

        // HEAD GROUP (with smooth nodding & facial expressions)
        ctx.save();
        ctx.translate(baseX, bodyY - 140);
        ctx.rotate(headNod);

        // Neck
        drawRoundedRect(-13, -18, 26, 28, 10, '#f3c19d');

        // Hijab outer frame around face
        ctx.fillStyle = palette.hijabMain;
        ctx.beginPath();
        ctx.arc(0, -56, 54, 0, Math.PI * 2);
        ctx.fill();

        // Hijab soft wrap bottom
        ctx.fillStyle = palette.hijabMain;
        ctx.beginPath();
        ctx.ellipse(0, -10, 48, 24, 0, 0, Math.PI * 2);
        ctx.fill();

        // Hijab specular highlight curve
        ctx.strokeStyle = palette.hijabHighlight;
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(-4, -58, 46, -2.3, -0.9);
        ctx.stroke();

        // Inner white under-scarf band
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, -53, 42, Math.PI * 0.9, Math.PI * 2.1);
        ctx.fill();

        // Cartoon Face
        ctx.fillStyle = '#fde0c8';
        ctx.beginPath();
        ctx.ellipse(0, -50, 38, 41, 0, 0, Math.PI * 2);
        ctx.fill();

        // Rosy cheeks
        ctx.fillStyle = 'rgba(244, 114, 182, 0.32)';
        ctx.beginPath();
        ctx.ellipse(-22, -41, 8, 5, 0, 0, Math.PI * 2);
        ctx.ellipse(22, -41, 8, 5, 0, 0, Math.PI * 2);
        ctx.fill();

        // Expressive Eyebrows (raise slightly while emphasizing!)
        const browLift = playing ? Math.max(0, Math.sin(timeSec * 3.1)) * 3.5 : 0;
        ctx.strokeStyle = '#3f2e26';
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-23, -67 - browLift);
        ctx.quadraticCurveTo(-14, -71 - browLift, -7, -67 - browLift);
        ctx.moveTo(7, -67 - browLift);
        ctx.quadraticCurveTo(14, -71 - browLift, 23, -67 - browLift);
        ctx.stroke();

        // Blinking Cartoon Eyes
        const blinkCycle = timeSec % 3.4;
        const isBlinking = blinkCycle > 3.24;
        const pupilShiftX = playing ? -2.5 + Math.sin(timeSec * 1.3) * 1.5 : -1;

        [-14, 14].forEach((ex) => {
          const ey = -55;
          if (isBlinking) {
            ctx.strokeStyle = '#1e293b';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(ex, ey + 2, 6, 0.15 * Math.PI, 0.85 * Math.PI);
            ctx.stroke();
          } else {
            // Sclera
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.ellipse(ex, ey, 7.5, 8.5, 0, 0, Math.PI * 2);
            ctx.fill();
            // Iris/pupil looking slightly toward the chalkboard!
            ctx.fillStyle = '#1e293b';
            ctx.beginPath();
            ctx.arc(ex + pupilShiftX, ey, 4.5, 0, Math.PI * 2);
            ctx.fill();
            // Eye catchlight sparkle
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(ex + pupilShiftX + 1.6, ey - 1.8, 1.7, 0, Math.PI * 2);
            ctx.fill();
          }
        });

        // Cute cartoon nose
        ctx.strokeStyle = '#d99b78';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(0, -45, 3, 0.2, Math.PI - 0.3);
        ctx.stroke();

        // LIP-SYNCING ANIMATED MOUTH
        const mouthWave = playing
          ? (Math.sin(timeSec * talkSpeed) + 1) * 0.5 * (speaking ? 1 : 0.85)
          : 0;

        if (!playing || mouthWave < 0.18) {
          // Warm friendly smile
          ctx.strokeStyle = '#b91c1c';
          ctx.lineWidth = 2.8;
          ctx.beginPath();
          ctx.arc(0, -34, 10, 0.15 * Math.PI, 0.85 * Math.PI);
          ctx.stroke();
        } else {
          // Open talking mouth with teeth & tongue
          const openH = 4 + mouthWave * 8;
          const openW = 8 + Math.sin(timeSec * 6.5) * 2.5;
          ctx.fillStyle = '#7f1d1d';
          ctx.beginPath();
          ctx.ellipse(0, -30, openW, openH, 0, 0, Math.PI * 2);
          ctx.fill();
          // Upper teeth strip
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.ellipse(0, -30 - openH * 0.45, openW * 0.72, Math.max(1.5, openH * 0.25), 0, 0, Math.PI);
          ctx.fill();
          // Tongue
          ctx.fillStyle = '#fb7185';
          ctx.beginPath();
          ctx.ellipse(0, -30 + openH * 0.42, openW * 0.55, Math.max(1.5, openH * 0.3), 0, Math.PI, Math.PI * 2);
          ctx.fill();
        }

        // Round glasses (subtle scholarly warmth)
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(-14, -55, 11, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(14, -55, 11, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-3, -55);
        ctx.lineTo(3, -55);
        ctx.stroke();

        ctx.restore(); // end HEAD GROUP

        // 9. LEFT POINTING ARM + ANIMATED POINTER STICK TOUCHING THE CHALKBOARD!
        // Smoothly point between chalkboard top/middle/formula based on sceneProgress & time
        const targetBoardX = 505 + Math.sin(timeSec * 2.4) * 35;
        const targetBoardY = 175 + Math.sin(sProg * Math.PI * 2 + timeSec * 1.9) * 62;

        const shoulderX = baseX - 54;
        const shoulderY = bodyY - 108;
        const elbowX = shoulderX - 42 + Math.sin(timeSec * 2.8) * (playing ? 7 : 2);
        const elbowY = shoulderY + 28 + Math.cos(timeSec * 2.2) * (playing ? 6 : 2);
        const handX = elbowX - 38;
        const handY = elbowY - 22 + (playing ? Math.sin(timeSec * 3.4) * 9 : 0);

        // Upper arm & forearm
        ctx.strokeStyle = palette.blazerMain;
        ctx.lineWidth = 22;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(shoulderX, shoulderY);
        ctx.lineTo(elbowX, elbowY);
        ctx.lineTo(handX, handY);
        ctx.stroke();

        // Pointer Stick extending from hand toward chalkboard spot
        const dx = targetBoardX - handX;
        const dy = targetBoardY - handY;
        const len = Math.hypot(dx, dy) || 1;
        const tipX = handX + (dx / len) * Math.min(len, 145);
        const tipY = handY + (dy / len) * Math.min(len, 145);

        ctx.strokeStyle = '#d97706';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(handX + 4, handY + 4);
        ctx.lineTo(tipX, tipY);
        ctx.stroke();

        // Glowing pointer tip on board
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(tipX, tipY, playing ? 5.5 + Math.sin(timeSec * 8) * 1.5 : 4.5, 0, Math.PI * 2);
        ctx.fill();

        // Cartoon hand gripping pointer
        ctx.fillStyle = '#fbd3b6';
        ctx.beginPath();
        ctx.arc(handX, handY, 12, 0, Math.PI * 2);
        ctx.fill();

        // Emit chalk-spark particles when playing!
        if (playing && Math.random() < 0.35) {
          sparks.push({
            x: tipX,
            y: tipY,
            vx: (Math.random() - 0.5) * 42,
            vy: -15 - Math.random() * 35,
            life: 0,
            maxLife: 0.45 + Math.random() * 0.35,
            color: Math.random() > 0.4 ? '#fde047' : '#ffffff',
          });
        }

        for (let i = sparks.length - 1; i >= 0; i--) {
          const sp = sparks[i];
          sp.life += dt;
          if (sp.life >= sp.maxLife) {
            sparks.splice(i, 1);
            continue;
          }
          sp.x += sp.vx * dt;
          sp.y += sp.vy * dt;
          sp.vy += 40 * dt;
          const alpha = 1 - sp.life / sp.maxLife;
          ctx.fillStyle = sp.color;
          ctx.globalAlpha = alpha;
          ctx.beginPath();
          ctx.arc(sp.x, sp.y, 2.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1;
        }

        // 10. Two Cute Cartoon Student Silhouettes / Listening Stars at bottom right corner
        // Subtle animated attentive little cartoon mascots/books on desk
        const deskY = 468;
        drawRoundedRect(640, deskY, 270, 52, 12, '#d97706', '#92400e', 2);
        drawRoundedRect(660, deskY - 12, 58, 12, 4, '#2563eb');
        drawRoundedRect(666, deskY - 21, 48, 9, 3, '#ef4444');
        drawRoundedRect(732, deskY - 14, 34, 14, 4, '#f8fafc', '#94a3b8', 1.5);

        ctx.restore();
      }

      animId = requestAnimationFrame(renderFrame);
    };

    animId = requestAnimationFrame(renderFrame);

    return () => {
      cancelAnimationFrame(animId);
      ro.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-label="فيديو كرتوني متحرك للأستاذة نجلاء فتحي داخل الفصل"
      className="w-full h-full block"
    />
  );
}
