import { useId } from 'react';

interface AcademyEmblemProps {
  size?: number;
  className?: string;
}

export function AcademyEmblem({ size = 36, className = '' }: AcademyEmblemProps) {
  const uid = useId().replace(/:/g, '');
  const bgId = `nfCrestBg-${uid}`;
  const goldId = `nfCrestGold-${uid}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={bgId} x1="6" y1="4" x2="58" y2="60" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#1E3A8A" />
          <stop offset="60%" stopColor="#0F172A" />
          <stop offset="100%" stopColor="#090D16" />
        </linearGradient>
        <linearGradient id={goldId} x1="18" y1="10" x2="46" y2="50" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FDE68A" />
          <stop offset="50%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>
      </defs>

      <rect x="2" y="2" width="60" height="60" rx="15" fill={`url(#${bgId})`} />
      <rect x="4" y="4" width="56" height="56" rx="13" stroke={`url(#${goldId})`} strokeOpacity="0.4" strokeWidth="1.2" />

      {/* Open Book Pages */}
      <path
        d="M14 29C14 27.3431 15.3431 26 17 26H27.5C30 26 32 28 32 30.5V48C29.8 46.1 26.5 45 22.5 45H17C15.3431 45 14 43.6569 14 42V29Z"
        fill="#FFFFFF"
      />
      <path
        d="M50 29C50 27.3431 48.6569 26 47 26H36.5C34 26 32 28 32 30.5V48C34.2 46.1 37.5 45 41.5 45H47C48.6569 45 50 43.6569 50 42V29Z"
        fill="#E2E8F0"
      />
      <path d="M12.5 31V43.5C12.5 45.433 14.067 47 16 47H23C26.8 47 29.8 48 32 49.8C34.2 48 37.2 47 41 47H48C49.933 47 51.5 45.433 51.5 43.5V31" stroke={`url(#${goldId})`} strokeWidth="2.2" strokeLinecap="round" />

      {/* Crisp Knowledge Lines */}
      <path d="M18.5 32.5H27M18.5 37H25" stroke="#94A3B8" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M37 32.5H45.5M39 37H45.5" stroke="#2563EB" strokeOpacity="0.55" strokeWidth="1.8" strokeLinecap="round" />

      {/* Ascending Nib Crest */}
      <path
        d="M32 11.5L38 22L34.2 27.5H29.8L26 22L32 11.5Z"
        fill={`url(#${goldId})`}
        stroke="#FFFFFF"
        strokeWidth="1.1"
        strokeLinejoin="round"
      />
      <path d="M32 12.5V20.5" stroke="#0F172A" strokeWidth="1.2" strokeLinecap="round" />
      <circle cx="32" cy="21.8" r="1.4" fill="#0F172A" />

      {/* Guiding Star */}
      <path d="M47 13L48.3 16L51.3 17.3L48.3 18.6L47 21.6L45.7 18.6L42.7 17.3L45.7 16L47 13Z" fill="#FBBF24" />
    </svg>
  );
}

interface BrandLogoProps {
  brandName?: string;
  size?: number;
  showText?: boolean;
  className?: string;
}

export function BrandLogo({
  brandName = 'منصة الأستاذة نجلاء فتحي',
  size = 36,
  showText = true,
  className = '',
}: BrandLogoProps) {
  return (
    <span className={`inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 ${className}`}>
      <AcademyEmblem size={size} />
      {showText && (
        <span className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 dark:text-slate-100 font-display whitespace-nowrap">
          {brandName}
        </span>
      )}
    </span>
  );
}
