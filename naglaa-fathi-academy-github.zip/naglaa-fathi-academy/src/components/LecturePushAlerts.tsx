import { Bell, BellRing, Clock, Play, Volume2, VolumeX, X } from 'lucide-react';
import { useAcademy } from '../context/AcademyContext.tsx';
import { BRANCH_LABELS, GRADE_SHORT_LABELS } from '../utils/academy.ts';

function formatCountdown(secondsUntilStart: number): string {
  if (secondsUntilStart <= 0) return 'بدأت الآن';
  const hrs = Math.floor(secondsUntilStart / 3600);
  const mins = Math.floor((secondsUntilStart % 3600) / 60);
  const secs = secondsUntilStart % 60;
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  if (hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${mm}:${ss}`;
  }
  return `${mm}:${ss}`;
}

function formatClockTime(iso: string): string {
  try {
    return new Intl.DateTimeFormat('ar-EG', {
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(iso));
  } catch {
    return '';
  }
}

export function LecturePushAlerts() {
  const {
    lectureSchedules,
    activePushAlerts,
    nowMs,
    pushPrefs,
    updatePushPrefs,
    isAlertsOpen,
    setIsAlertsOpen,
    dismissPushAlert,
    snoozePushAlert,
    testPushAlert,
    openCourse,
  } = useAcademy();

  const browserSupported = typeof window !== 'undefined' && 'Notification' in window;
  const browserPermission = browserSupported ? Notification.permission : 'denied';

  return (
    <>
      {/* Notification Center Modal / Drawer opened from Header Bell */}
      {isAlertsOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/40 backdrop-blur-[1px] flex justify-center sm:justify-end items-start pt-16 px-4"
          onClick={() => setIsAlertsOpen(false)}
        >
          <section
            aria-label="مركز تنبيهات المحاضرات القادمة"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[82vh]"
          >
            <div className="bg-slate-900 dark:bg-slate-950 text-white px-5 py-4 flex items-center justify-between gap-3 border-b border-transparent dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <BellRing className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <h2 className="text-sm font-extrabold font-display">تنبيهات ومواعيد المحاضرات</h2>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    إشعارات تلقائية قبل موعد كل محاضرة داخل المنصة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAlertsOpen(false)}
                aria-label="إغلاق مركز التنبيهات"
                className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Notification Preferences Controls */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 space-y-3 text-xs">
              <div className="flex items-center justify-between gap-3">
                <span className="font-bold text-slate-800 dark:text-slate-200">تفعيل التنبيهات المنبثقة داخل التطبيق</span>
                <button
                  type="button"
                  onClick={() => void updatePushPrefs({ enabled: !pushPrefs.enabled })}
                  className={`px-3 py-1.5 min-h-[36px] rounded-lg font-bold transition-colors cursor-pointer ${
                    pushPrefs.enabled
                      ? 'bg-emerald-700 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                  }`}
                >
                  {pushPrefs.enabled ? 'مفعل' : 'متوقف'}
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 font-semibold">
                  <span>تذكيري قبل الموعد بـ</span>
                  <select
                    value={pushPrefs.leadMinutes}
                    onChange={(e) => void updatePushPrefs({ leadMinutes: Number(e.target.value) })}
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold font-mono text-slate-900 dark:text-slate-100"
                  >
                    <option value={5}>5 دقائق</option>
                    <option value={10}>10 دقائق</option>
                    <option value={15}>15 دقيقة</option>
                    <option value={30}>30 دقيقة</option>
                    <option value={60}>60 دقيقة</option>
                  </select>
                </label>

                <button
                  type="button"
                  onClick={() => void updatePushPrefs({ soundEnabled: !pushPrefs.soundEnabled })}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-slate-400 text-slate-800 dark:text-slate-200 font-semibold rounded-lg cursor-pointer"
                >
                  {pushPrefs.soundEnabled ? (
                    <Volume2 className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                  ) : (
                    <VolumeX className="w-3.5 h-3.5 text-slate-400" />
                  )}
                  <span>{pushPrefs.soundEnabled ? 'النغمة مفعلة' : 'صامت'}</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200 dark:border-slate-700">
                {browserSupported ? (
                  <button
                    type="button"
                    onClick={() =>
                      void updatePushPrefs({ browserNotifications: !pushPrefs.browserNotifications })
                    }
                    className="text-xs font-semibold text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 cursor-pointer"
                  >
                    {pushPrefs.browserNotifications && browserPermission === 'granted'
                      ? 'إشعارات المتصفح الخارجية مفعلة'
                      : browserPermission === 'denied'
                        ? 'إشعارات المتصفح محجوبة من الإعدادات (تعمل التنبيهات الداخلية)'
                        : 'تفعيل إشعارات المتصفح الخارجية (Push)'}
                  </button>
                ) : (
                  <span className="text-slate-500 dark:text-slate-400">التنبيهات الداخلية مفعلة تلقائياً</span>
                )}

                <button
                  type="button"
                  onClick={() => {
                    testPushAlert();
                    setIsAlertsOpen(false);
                  }}
                  className="px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg transition-colors cursor-pointer"
                >
                  تجربة تنبيه الآن
                </button>
              </div>
            </div>

            {/* Upcoming Scheduled Lectures List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span className="font-bold text-slate-800 dark:text-slate-200">جدول المحاضرات القادمة</span>
                <span className="font-mono tabular-nums">{lectureSchedules.length} مواعيد</span>
              </div>

              {lectureSchedules.length === 0 ? (
                <p className="py-8 text-center text-xs text-slate-500 dark:text-slate-400">
                  لا توجد محاضرات مجدولة حالياً.
                </p>
              ) : (
                lectureSchedules.map((sch) => {
                  const startMs = new Date(sch.scheduledAt).getTime();
                  const endMs = startMs + sch.durationMin * 60_000;
                  const secsLeft = Math.round((startMs - nowMs) / 1000);
                  const isEnded = nowMs > endMs;
                  const isSoonOrLive =
                    !isEnded &&
                    secsLeft <= Math.max(pushPrefs.leadMinutes, sch.remindBeforeMin) * 60;

                  return (
                    <div
                      key={sch.id}
                      className={`rounded-xl border p-3.5 space-y-2 ${
                        isSoonOrLive
                          ? 'bg-amber-50/70 dark:bg-amber-950/40 border-amber-300 dark:border-amber-700'
                          : 'bg-white dark:bg-slate-800/60 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-400">
                        <span>
                          {GRADE_SHORT_LABELS[sch.grade]} · {BRANCH_LABELS[sch.branch]} ·{' '}
                          {formatClockTime(sch.scheduledAt)}
                        </span>
                        <span
                          className={`font-mono tabular-nums font-bold ${
                            isEnded
                              ? 'text-slate-400 dark:text-slate-500'
                              : secsLeft <= 0
                                ? 'text-emerald-700 dark:text-emerald-400'
                                : isSoonOrLive
                                  ? 'text-amber-700 dark:text-amber-400'
                                  : 'text-blue-700 dark:text-blue-400'
                          }`}
                        >
                          {isEnded ? 'انتهت' : formatCountdown(secsLeft)}
                        </span>
                      </div>

                      <h3 className="text-xs font-extrabold text-slate-900 dark:text-slate-100">{sch.lessonTitle}</h3>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300">{sch.courseTitle}</p>
                      {sch.note && <p className="text-[11px] text-slate-500 dark:text-slate-400">{sch.note}</p>}

                      <div className="pt-1 flex items-center justify-between gap-2">
                        <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                          المدة {sch.durationMin} دقيقة
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            openCourse(sch.courseId);
                            setIsAlertsOpen(false);
                          }}
                          className="inline-flex items-center gap-1 px-3 py-1.5 min-h-[36px] bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800 text-white text-[11px] font-bold rounded-lg transition-colors cursor-pointer"
                        >
                          <Play className="w-3 h-3" />
                          <span>دخول القاعة</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>
        </div>
      )}

      {/* Floating In-App Push UI Alerts Stack (Bottom Right — opposite Chat Drawer) */}
      {activePushAlerts.length > 0 && (
        <aside
          aria-live="polite"
          aria-label="تنبيهات المحاضرات القادمة"
          className="fixed bottom-5 right-5 z-50 w-[calc(100vw-2.5rem)] max-w-sm space-y-3"
        >
          {activePushAlerts.slice(0, 2).map((alert) => {
            const { schedule, secondsUntilStart, isLiveNow, customTitle, customBody } = alert;
            return (
              <div
                key={schedule.id}
                role="alert"
                className="bg-slate-900 text-white border border-slate-700 rounded-2xl p-4 shadow-2xl space-y-2.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 text-amber-300 text-xs font-extrabold">
                    <Bell className="w-4 h-4 shrink-0" />
                    <span>
                      {customTitle ||
                        (isLiveNow ? 'موعد المحاضرة بدأ الآن' : 'اقترب موعد المحاضرة القادمة')}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => dismissPushAlert(schedule.id)}
                    aria-label="إغلاق التنبيه"
                    className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-1">
                  <p className="text-sm font-extrabold font-display text-white">
                    {schedule.lessonTitle}
                  </p>
                  <p className="text-xs text-slate-300">
                    {customBody || `${GRADE_SHORT_LABELS[schedule.grade]} · ${schedule.courseTitle}`}
                  </p>
                  {schedule.note && (
                    <p className="text-[11px] text-slate-400 leading-relaxed">{schedule.note}</p>
                  )}
                </div>

                <div className="flex items-center justify-between gap-2 pt-1 text-xs">
                  <div className="inline-flex items-center gap-1.5 text-emerald-300 font-mono tabular-nums font-bold">
                    <Clock className="w-3.5 h-3.5 shrink-0" />
                    <span>
                      {isLiveNow
                        ? 'جارية الآن'
                        : `تبدأ خلال ${formatCountdown(secondsUntilStart)}`}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                    {formatClockTime(schedule.scheduledAt)}
                  </span>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      openCourse(schedule.courseId);
                      dismissPushAlert(schedule.id);
                    }}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[40px] bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 shrink-0" />
                    <span>دخول المحاضرة</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => snoozePushAlert(schedule.id, 5)}
                    className="px-3 py-2 min-h-[40px] bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors cursor-pointer whitespace-nowrap"
                  >
                    تأجيل 5 د
                  </button>
                </div>
              </div>
            );
          })}
        </aside>
      )}
    </>
  );
}
