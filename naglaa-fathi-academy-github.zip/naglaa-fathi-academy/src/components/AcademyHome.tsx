import { useMemo, useState } from 'react';
import { ArrowLeft, BookOpen, CheckCircle2, Download, KeyRound, Lock, MessageCircle, MessageSquare, Phone, Play, Sparkles, Star } from 'lucide-react';
import { useAcademy } from '../context/AcademyContext.tsx';
import type { GradeLevel } from '../types.ts';
import { BRANCH_LABELS, formatEgp, GRADE_LABELS, GRADE_SHORT_LABELS } from '../utils/academy.ts';
import { AcademyEmblem } from './BrandLogo.tsx';
import { SafeImage } from './SafeImage.tsx';
import { formatPhoneDigits, formatWhatsappHref } from './SupportChatDrawer.tsx';

export function AcademyHome() {
  const {
    snapshot,
    currentStudent,
    openCourse,
    setActiveSection,
    setIsChatOpen,
    redeemCode,
    downloadAuthorizedCurriculum,
  } = useAcademy();

  const [gradeFilter, setGradeFilter] = useState<GradeLevel | 'all_primary'>('all_primary');
  const [subjectFilter, setSubjectFilter] = useState<'all' | 'arabic' | 'math'>('all');
  const [downloadGrade, setDownloadGrade] = useState<GradeLevel | 'all'>('all');
  const [quickCode, setQuickCode] = useState('');
  const [redeeming, setRedeeming] = useState(false);

  const profile = snapshot?.profile;
  const allCourses = snapshot?.courses || [];
  const announcements = snapshot?.announcements || [];
  const courseRatingMap = useMemo(() => {
    const grouped = new Map<string, { sum: number; count: number }>();
    for (const rev of snapshot?.lessonReviews || []) {
      const entry = grouped.get(rev.courseId) || { sum: 0, count: 0 };
      entry.sum += rev.overallRating;
      entry.count += 1;
      grouped.set(rev.courseId, entry);
    }
    const result = new Map<string, { avg: number; count: number }>();
    grouped.forEach((v, k) => {
      result.set(k, { avg: Number((v.sum / v.count).toFixed(1)), count: v.count });
    });
    return result;
  }, [snapshot?.lessonReviews]);

  const primaryCourses = useMemo(() => {
    return allCourses.filter((c) => c.grade !== 'kg');
  }, [allCourses]);

  const filteredCourses = useMemo(() => {
    return primaryCourses.filter((c) => {
      const matchGrade = gradeFilter === 'all_primary' || c.grade === gradeFilter;
      const matchSubject = subjectFilter === 'all' || c.branch === subjectFilter;
      return matchGrade && matchSubject;
    });
  }, [primaryCourses, gradeFilter, subjectFilter]);

  const handleQuickRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickCode.trim()) return;
    setRedeeming(true);
    const ok = await redeemCode(quickCode.trim());
    if (ok) setQuickCode('');
    setRedeeming(false);
  };

  const handleDownloadCurriculumBundle = (format: 'html' | 'doc') => {
    void downloadAuthorizedCurriculum({ grade: downloadGrade, format });
  };

  const gradeTabs: { id: GradeLevel | 'all_primary'; label: string }[] = [
    { id: 'all_primary', label: 'كل الصفوف (1–6)' },
    { id: 'p1', label: 'أولى ابتدائي' },
    { id: 'p2', label: 'تانية ابتدائي' },
    { id: 'p3', label: 'تالتة ابتدائي' },
    { id: 'p4', label: 'رابعة ابتدائي' },
    { id: 'p5', label: 'خامسة ابتدائي' },
    { id: 'p6', label: 'سادسة ابتدائي' },
  ];

  const subjectTabs: { id: 'all' | 'arabic' | 'math'; label: string }[] = [
    { id: 'all', label: 'العربي والرياضيات' },
    { id: 'arabic', label: 'اللغة العربية' },
    { id: 'math', label: 'الرياضيات' },
  ];

  const scrollToCatalog = () => {
    const el = document.getElementById('primary-courses-catalog');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="space-y-12 pb-10">
      {/* Hero Split — Balanced 2 Columns */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-10 flex flex-col justify-between">
          <div className="space-y-5">
            <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-blue-700 dark:text-blue-400">
              <AcademyEmblem size={28} />
              <span>
                {profile?.platformName || 'منصة الأستاذة نجلاء فتحي'} · {profile?.academicYear || '2026 / 2027'}
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-slate-100 leading-tight font-display">
              تأسيس وإتقان اللغة العربية والرياضيات للمرحلة الابتدائية
            </h1>

            <p className="text-base text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
              {profile?.teacherBio ||
                'فيديوهات شرح كرتونية بصوت وصورة الأستاذة نجلاء فتحي لجميع دروس اللغة العربية والرياضيات من الصف الأول حتى السادس الابتدائي، مقسمة إلى 8 محاضرات شهرياً مع تنزيل المنهج وقسم متكامل لرياض الأطفال.'}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => openCourse('crs-p1-ar')}
                className="inline-flex items-center gap-2 px-6 py-3 min-h-[44px] bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>شاهد فيديو شرح كرتوني مجاني</span>
              </button>

              <button
                type="button"
                onClick={scrollToCatalog}
                className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 text-sm font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <BookOpen className="w-4 h-4" />
                <span>كل الصفوف (8 محاضرات/شهر)</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveSection('kindergarten')}
                className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800 text-amber-950 dark:text-amber-200 text-sm font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>تأسيس رياض الأطفال (جميع المواد)</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            <span className="font-semibold text-slate-800 dark:text-slate-200">{profile?.teacherName || 'الأستاذة نجلاء فتحي'}</span>
            <span aria-hidden="true">·</span>
            <span>فيديوهات شرح كرتونية لكل مادة</span>
            <span aria-hidden="true">·</span>
            <span>8 محاضرات في الشهر (4 أسابيع)</span>
            <span aria-hidden="true">·</span>
            <span>تنزيل المنهج لكل المواد</span>
          </div>
        </div>

        {/* Visual Focal Anchor */}
        <div className="lg:col-span-5 relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 min-h-[320px]">
          <SafeImage
            src="/src/assets/images/primary_hero_banner_1795354179862.jpg"
            alt="طاولة دراسة للمرحلة الابتدائية مع مكعبات الحساب وبطاقات الحروف العربية"
            className="w-full h-full lg:h-full object-cover"
            fallbackTitle="منصة الأستاذة نجلاء فتحي"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/35 to-transparent flex flex-col justify-end p-6">
            <p className="text-xs text-slate-300 mb-1">إشراف الأستاذة نجلاء فتحي</p>
            <p className="text-xl font-bold text-white font-display">
              تأسيس سليم في القراءة والحساب منذ الصغر
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
              <a
                href={`tel:${formatPhoneDigits(profile?.hotline || '01029121467')}`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/15 hover:bg-white/25 text-white font-semibold rounded-lg backdrop-blur-sm transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span className="font-mono tabular-nums" dir="ltr">
                  {profile?.hotline || '01029121467'}
                </span>
              </a>
              <a
                href={formatWhatsappHref(profile?.hotline || '01029121467')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>تواصل واتساب</span>
              </a>
              <button
                type="button"
                onClick={() => setIsChatOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>محادثة داخل الموقع</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4-Column Methodology Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1.5">01. فيديوهات كرتونية بصوت الأستاذة</h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            شخصية كرتونية للأستاذة نجلاء فتحي تشرح على السبورة بالصوت والحركة كل قاعدة ومثال.
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1.5">02. 8 محاضرات في الشهر</h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            كل كورس شهري مقسم إلى 4 أسابيع بواقع محاضرتين أسبوعياً مع متابعة دقيقة لتقدم الطالب.
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1.5">03. صفحة تأسيس رياض الأطفال</h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            قسم مستقل لأطفال KG1 و KG2 يشمل العربي والحساب والإنجليزي Phonics ومادة اكتشف.
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1.5">04. تنزيل المنهج واختبارات إلكترونية</h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            تحميل المنهج للطباعة واختبار مصحح تلقائياً لكل كورس بعد الدفع عبر فوري باي أو الكود.
          </p>
        </div>
      </section>

      {/* Download Full Curriculum Bar for All Grades & Subjects */}
      <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-semibold text-amber-400">
            مكتبة تنزيل المناهج — الأستاذة نجلاء فتحي
          </p>
          <h2 className="text-xl sm:text-2xl font-bold font-display">
            تنزيل مناهج المواد المفعلة على حسابك
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            يتاح تنزيل المنهج الكامل (الدروس، القواعد، المذكرات، وأسئلة التقييم) للمواد المجانية ولكل كورس شهري تم سداده وتفعيله على حساب الطالب.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
          <select
            value={downloadGrade}
            onChange={(e) => setDownloadGrade(e.target.value as GradeLevel | 'all')}
            aria-label="اختر الصف لتنزيل المنهج"
            className="px-3.5 py-2.5 min-h-[42px] bg-slate-800 border border-slate-700 text-white text-xs font-semibold rounded-xl focus:outline-none focus:border-blue-500"
          >
            <option value="all">جميع الصفوف والمواد (KG + 1–6 ابتدائي)</option>
            {Object.entries(GRADE_LABELS).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => handleDownloadCurriculumBundle('html')}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[42px] bg-white text-slate-900 hover:bg-slate-100 text-xs font-bold rounded-xl whitespace-nowrap cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل المنهج (للطباعة)</span>
          </button>

          <button
            type="button"
            onClick={() => handleDownloadCurriculumBundle('doc')}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[42px] bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl whitespace-nowrap cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>ملف Word</span>
          </button>
        </div>
      </section>

      {/* Primary School Catalog (Grades 1 to 6) */}
      <section id="primary-courses-catalog" className="space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-display">
              دروس العربي والرياضيات (أولى إلى سادسة ابتدائي)
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              اختر الصف الابتدائي والمادة للاستماع للشرح الصوتي وتنزيل المنهج وأداء الاختبار
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-transparent dark:border-slate-800 rounded-xl overflow-x-auto">
            {subjectTabs.map((tab) => {
              const active = subjectFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSubjectFilter(tab.id)}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active ? 'bg-blue-700 text-white' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Grade Segmented Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-transparent dark:border-slate-800 rounded-xl overflow-x-auto">
            {gradeTabs.map((tab) => {
              const active = gradeFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setGradeFilter(tab.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            عرض {filteredCourses.length} من إجمالي {primaryCourses.length} كورسات ابتدائي
          </p>
        </div>

        {/* Course Cards Grid */}
        {filteredCourses.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center">
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">لا توجد دروس مطابقة لهذا التحديد</p>
            <button
              type="button"
              onClick={() => {
                setGradeFilter('all_primary');
                setSubjectFilter('all');
              }}
              className="mt-3 px-4 py-2 text-xs font-semibold text-blue-700 dark:text-blue-400 cursor-pointer"
            >
              إظهار جميع صفوف الابتدائي
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map((course) => {
              const isEnrolled =
                course.priceEgp === 0 || Boolean(currentStudent?.enrolledCourseIds.includes(course.id));

              return (
                <article
                  key={course.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                >
                  <div>
                    <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100 dark:bg-slate-800 border-b border-slate-100 dark:border-slate-800">
                      <SafeImage
                        src={course.coverImage}
                        alt={course.title}
                        className="w-full h-full object-cover"
                        fallbackTitle={course.title}
                      />
                    </div>

                    <div className="p-5 space-y-3">
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-semibold text-blue-700 dark:text-blue-400">
                          {GRADE_SHORT_LABELS[course.grade]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{BRANCH_LABELS[course.branch]}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{course.lessons.length} محاضرات شهرياً</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{course.totalHours} ساعات</span>
                        {courseRatingMap.has(course.id) && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="inline-flex items-center gap-0.5 font-bold text-amber-700 dark:text-amber-400 font-mono tabular-nums">
                              <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                              <span>{courseRatingMap.get(course.id)!.avg}</span>
                            </span>
                          </>
                        )}
                      </div>

                      <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 leading-snug font-display">
                        {course.title}
                      </h3>

                      <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2">
                        {course.subtitle}
                      </p>
                    </div>
                  </div>

                  <div className="px-5 pb-5 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-lg font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
                            {formatEgp(course.priceEgp)}
                          </span>
                          {course.originalPriceEgp && course.originalPriceEgp > course.priceEgp ? (
                            <span className="text-xs text-slate-400 dark:text-slate-500 line-through tabular-nums">
                              {course.originalPriceEgp} ج.م
                            </span>
                          ) : null}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {isEnrolled ? (
                            <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>متاح على حسابك</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-amber-800 dark:text-amber-400 font-semibold">
                              <Lock className="w-3 h-3" />
                              <span>يتطلب السداد عبر فوري باي</span>
                            </span>
                          )}
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {isEnrolled && (
                          <button
                            type="button"
                            onClick={() =>
                              void downloadAuthorizedCurriculum({ courseId: course.id, format: 'html' })
                            }
                            title="تنزيل منهج المادة"
                            className="inline-flex items-center gap-1 px-3 py-2.5 min-h-[40px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>المنهج</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => openCourse(course.id)}
                          className={`inline-flex items-center gap-1.5 px-3.5 py-2.5 min-h-[40px] text-xs font-semibold rounded-xl transition-colors whitespace-nowrap cursor-pointer ${
                            isEnrolled
                              ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                              : 'bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800 text-white'
                          }`}
                        >
                          {isEnrolled ? <Play className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                          <span>{isEnrolled ? 'ابدأ' : 'ادفع وافتح'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Activation Code + Parent Testimonials */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-5">
          <div className="space-y-2">
            <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">تفعيل بطاقات وكروت الاشتراك</p>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 font-display">
              تفعيل كورس الطالب بكود الاشتراك
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              أدخل كود الكارت لفتح دروس الصف مباشرة. للتجربة السريعة اضغط على الكود:{' '}
              <button
                type="button"
                onClick={() => setQuickCode('QEMA-P4-MATH')}
                className="font-mono font-semibold text-blue-700 dark:text-blue-400 underline cursor-pointer"
              >
                QEMA-P4-MATH
              </button>
            </p>
          </div>

          <form onSubmit={(e) => void handleQuickRedeem(e)} className="space-y-3">
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <KeyRound className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  dir="ltr"
                  value={quickCode}
                  onChange={(e) => setQuickCode(e.target.value.toUpperCase())}
                  placeholder="QEMA-P4-MATH"
                  className="w-full pr-10 pl-3 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                />
              </div>
              <button
                type="submit"
                disabled={redeeming}
                className="px-5 py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 disabled:opacity-60 text-white text-xs font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {redeeming ? 'جاري التفعيل...' : 'تفعيل الكود'}
              </button>
            </div>
            {announcements[0] && (
              <p className="text-xs text-slate-500 dark:text-slate-400 pt-1">
                آخر تنبيه: {announcements[0].title}
              </p>
            )}
          </form>
        </div>

        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">آراء أولياء الأمور</p>
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 font-display">
                تقدم ملحوظ في القراءة والحساب
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setActiveSection('honor-roll')}
              className="text-xs font-semibold text-blue-700 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 whitespace-nowrap shrink-0 cursor-pointer"
            >
              لوحة شرف الطلاب
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span className="font-bold text-slate-900 dark:text-slate-100">ولية أمر الطالب يوسف (4 ابتدائي)</span>
                <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">100% عربي</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">القاهرة · المنهج الجديد</p>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                «أسلوب الأستاذة نجلاء فتحي في الشرح الصوتي والمرئي وتنزيل المنهج ساعد ابني على المذاكرة والحل بسهولة.»
              </p>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span className="font-bold text-slate-900 dark:text-slate-100">والد الطالبة ليلى (KG2)</span>
                <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">تأسيس شامل</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">الإسكندرية · قسم رياض الأطفال</p>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                «قسم تأسيس رياض الأطفال رائع لأنه يجمع نور البيان والحساب والإنجليزي Phonics واكتشف مع النطق الصوتي.»
              </p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>متاح جميع صفوف المرحلة الابتدائية (1 إلى 6) وقسم رياض الأطفال</span>
            </span>
          </div>
        </div>
      </section>
    </div>
  );
}
